package org.shuffle.seat;

import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Cursor;

public class StructAdminSignUp {
	private JTextField tfName;
	private JPasswordField PAS1;

	public StructAdminSignUp() {
		// TODO Auto-generated constructor stub
		JFrame f = new JFrame("Login");  
		JLabel title,labReg;
		
	    ImageIcon image = new ImageIcon("arrange-seat1.png");
	    f.setIconImage(image.getImage());
	    title=new JLabel("Admin SignUp");
	    title.setForeground(new Color(42, 13, 66));
	    title.setHorizontalAlignment(SwingConstants.CENTER);
	    title.setFont(new Font("Arial", Font.BOLD, 25));
	    title.setBounds(80,150, 369,58);
	    f.setUndecorated(true);
	    
	    JTextField tfREG_NO; JPasswordField PAS2;
	    tfREG_NO = new JTextField();
	    tfREG_NO.setBounds(152,240,240,40);
	    
		tfName = new JTextField();
		tfName.setBounds(152, 320, 240, 40);
		f.getContentPane().add(tfName);
		
		PAS1 = new JPasswordField();
		PAS1.setBounds(152, 400, 240, 40);
		f.getContentPane().add(PAS1);
	    
	    PAS2 = new JPasswordField();
	    PAS2.setBounds(152,480,240,40);
	    f.getContentPane().add(PAS2);
	    
	    JLabel lblNewLabel = new JLabel("");
	    lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
	    lblNewLabel.setBounds(550, 164, 800, 390);
	    f.getContentPane().add(lblNewLabel);
	    lblNewLabel.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\Logo-Large.png"));
	    
	    JButton log;
	    log = new JButton(" SignUp");
	    log.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\user (1).png"));
	    log.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	    log.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent evt) {
	    		
	    		if (!(new String(PAS1.getPassword()).equals(new String(PAS2.getPassword()))))
	    		{
	    			JOptionPane.showMessageDialog(f,"You Password Does not Match!","Alert",JOptionPane.WARNING_MESSAGE);
	    		}else {
	        		try {	
			    		Class.forName("com.mysql.cj.jdbc.Driver"); 
			    		java.sql.Connection con;
			    		con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange","root","adish");

			    		
			    		String query = "INSERT INTO ADMIN (REG_NO,NAME,PASSWORD) VALUES(?,?,?)";
			    		

			    		String AREG_NO = tfREG_NO.getText();
			    		String NAME = tfName.getText();
			    		String PAS = PAS1.getText();
			    		
			    		PreparedStatement ps = con.prepareCall(query);  	    		
			    		ps.setString(1,AREG_NO);
			    		ps.setString(2,NAME);
			    		ps.setString(3,PAS);
			    		
			    		int result = ps.executeUpdate();
			    		if (result == 1) {
			    			JOptionPane.showMessageDialog(f,"Account Created !!","Welcome", JOptionPane.PLAIN_MESSAGE);
			    			f.dispose();
			    			new StructAdminMenu(AREG_NO);
			    		}
			    		else {
			    		
			    			JOptionPane.showMessageDialog(f,"Something Went Wrong ","Alert",JOptionPane.ERROR_MESSAGE);
			    			tfREG_NO.setText("");
			    			PAS2.setText("");
			    		}
			    		
			    	}catch(Exception e) {
			    		System.out.println(e.getMessage());
			    	}
	    		}
	    	}
	    });
	    log.setFont(new Font("Tahoma", Font.BOLD, 17));

	    log.setBounds(152,560,240,40);
	    log.setBackground(new Color(0, 0, 70));
	    log.setForeground(new Color(255, 255, 255));
	    log.setBorderPainted(false);
	    
	    JLabel lblPassword_1 = new JLabel("Confirm Password");
	    lblPassword_1.setForeground(new Color(42, 13, 66));
	    lblPassword_1.setHorizontalAlignment(SwingConstants.LEFT);
	    lblPassword_1.setFont(new Font("Arial", Font.PLAIN, 15));
	    lblPassword_1.setBounds(160, 450, 146, 40);
	    f.getContentPane().add(lblPassword_1);
	    labReg = new JLabel("Register No");
	    labReg.setForeground(new Color(42, 13, 66));
	    labReg.setFont(new Font("Arial", Font.PLAIN, 15));
	    labReg.setHorizontalAlignment(SwingConstants.LEFT);
	    labReg.setBounds(160,210, 146,40);
	    f.getContentPane().add(labReg);

	    
		JButton btnClose = new JButton("");
		btnClose.setOpaque(false);
		btnClose.setBorder(null);
		btnClose.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});
		btnClose.setBackground(new Color(28, 181, 224));
		btnClose.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\cancel.png"));
		btnClose.setBounds(1315, 10, 40, 25);
		f.getContentPane().add(btnClose);

	    f.getContentPane().add(title);f.getContentPane().add(tfREG_NO);
	    f.getContentPane().add(log);
	    f.setSize(1366,768);  
	    f.getContentPane().setLayout(null);  
	    f.setVisible(true);  
		f.setResizable(false);
		f.getContentPane().setBackground(new Color(170, 111, 219));
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(527, -11, 862, 789);
		f.getContentPane().add(panel);
		
		JLabel lblName = new JLabel("Name");
		lblName.setHorizontalAlignment(SwingConstants.LEFT);
		lblName.setForeground(new Color(42, 13, 66));
		lblName.setFont(new Font("Arial", Font.PLAIN, 15));
		lblName.setBounds(160, 290, 146, 40);
		f.getContentPane().add(lblName);
		
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setHorizontalAlignment(SwingConstants.LEFT);
		lblPassword.setForeground(new Color(42, 13, 66));
		lblPassword.setFont(new Font("Arial", Font.PLAIN, 15));
		lblPassword.setBounds(160, 370, 146, 40);
		f.getContentPane().add(lblPassword);
		
		JLabel lblNewLabel_1 = new JLabel("have an account?, Click here ");
		lblNewLabel_1.setBackground(new Color(255, 255, 255));
		lblNewLabel_1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblNewLabel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new StructAdminLogin();
				f.dispose();
			}
		});
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setBounds(100, 647, 340, 30);
		f.getContentPane().add(lblNewLabel_1);
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(100, 120, 340, 530);
		f.getContentPane().add(panel_1);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setBorder(null);
		btnNewButton.setOpaque(false);
		btnNewButton.setBackground(new Color(170, 111, 219));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new StructAdminLogin();
				f.dispose();
			}
		});
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\left.png"));
		btnNewButton.setBounds(10, 11, 40, 40);
		f.getContentPane().add(btnNewButton);
		
	    JPanel gradientPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                int width = getWidth();
                int height = getHeight();
                GradientPaint gradient = new GradientPaint(0, 0, new Color(28, 181, 224), 0, height, new Color(0, 0, 70));
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, width, height);
                g2d.dispose();
                

            }
        };
		gradientPanel.setBounds(0, 0, 1366, 768);
	    f.getContentPane().add(gradientPanel);
	    gradientPanel.setLayout(null);
	    f.setLocationRelativeTo(null);

	}
}
