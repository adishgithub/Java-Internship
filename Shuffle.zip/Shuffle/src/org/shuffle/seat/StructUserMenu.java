package org.shuffle.seat;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JPanel;
import javax.swing.JTable;

import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import javax.swing.UIManager;
import java.awt.Cursor;


public class StructUserMenu {
	
	Connection con;
	PreparedStatement pst;
    PreparedStatement st;
	ResultSet rs,rs1;
	
	JFrame f;
	private JTable table;
	private String AREG_NO;
	JPanel panel_1_1;
	
	public void displayadmin(String REG_NO) throws SQLException, ClassNotFoundException {
	    String dquery = "SELECT * FROM ROOM WHERE REG_NO = ?";
	    Class.forName("com.mysql.cj.jdbc.Driver");
	    java.sql.Connection con1;
	    con1 = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange", "root", "adish");
	    PreparedStatement st1 = con1.prepareStatement(dquery);
	    try {
	        st1.setString(1, REG_NO);
	        ResultSet r1 = st1.executeQuery();

	        if (r1.next()) {
	            int room = r1.getInt("ROOM_NO");
	            String seat = r1.getString("SEAT");

	            JLabel lblRoom = new JLabel(": " + room);
	            lblRoom.setHorizontalAlignment(SwingConstants.LEFT);
	            lblRoom.setForeground(Color.BLACK);
	            lblRoom.setFont(new Font("Consolas", Font.BOLD, 40));
	            lblRoom.setBounds(230, 140, 220, 50);
	            panel_1_1.add(lblRoom);
	            System.out.print(room);

	            JLabel lblSeat = new JLabel(": " + seat);
	            lblSeat.setHorizontalAlignment(SwingConstants.LEFT);
	            lblSeat.setForeground(Color.BLACK);
	            lblSeat.setFont(new Font("Consolas", Font.BOLD, 40));
	            lblSeat.setBounds(230, 230, 220, 50);
	            panel_1_1.add(lblSeat);
	            System.out.print(seat);
	        } else {
	            JOptionPane.showMessageDialog(f, "Incorrect Reg. no or Password", "Alert", JOptionPane.WARNING_MESSAGE);
	        }

	    } catch (SQLException e) {
	        e.printStackTrace();
	    } finally {
	        st1.close();
	        con1.close();
	    }
	}


	
	public StructUserMenu(String REG_NO) throws ClassNotFoundException, SQLException {
		
		f = new JFrame("Login");  
		f.getContentPane().setBackground(new Color(115, 38, 191));
	    ImageIcon image = new ImageIcon("arrange-seat1.png");
	    f.setIconImage(image.getImage());
		
	    f.setUndecorated(true);
		f.getContentPane().setLayout(null);
		
		
		JButton btnMinimize = new JButton("");
		btnMinimize.setOpaque(false);
		btnMinimize.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.setState(f.ICONIFIED);
			}
		});
		
		JButton btnClose = new JButton("");
		btnClose.setOpaque(false);
		btnClose.setBorder(null);
		btnClose.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});
		btnClose.setBackground(new Color(242, 242, 242));
		btnClose.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\cancel.png"));
		btnClose.setBounds(1315, 10, 40, 25);
		f.getContentPane().add(btnClose);
		btnMinimize.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnMinimize.setBorder(null);
		btnMinimize.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\minimize-sign.png"));
		btnMinimize.setBounds(1270, 10, 40, 25);
		btnMinimize.setBackground(new Color(242, 242, 242));
		f.getContentPane().add(btnMinimize);
		
		JPanel panel_1_2 = new JPanel();
		panel_1_2.setLayout(null);
		panel_1_2.setForeground(new Color(115, 38, 191));
		panel_1_2.setBorder(new TitledBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null), "Class Details", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_1_2.setBounds(726, 220, 570, 480);
		f.getContentPane().add(panel_1_2);
		
		panel_1_1 = new JPanel();
		panel_1_1.setBackground(new Color(255, 255, 255));
		panel_1_1.setBounds(20, 30, 530, 430);
		panel_1_2.add(panel_1_1);
		panel_1_1.setLayout(null);
		panel_1_1.setForeground(new Color(115, 38, 191));
		panel_1_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		
		JLabel NAME_1 = new JLabel("Room No");
		NAME_1.setHorizontalAlignment(SwingConstants.LEFT);
		NAME_1.setForeground(Color.BLACK);
		NAME_1.setFont(new Font("Consolas", Font.BOLD, 40));
		NAME_1.setBounds(60, 140, 200, 50);
		panel_1_1.add(NAME_1);
		
		JLabel REG_NO_1 = new JLabel("Seat No");
		REG_NO_1.setHorizontalAlignment(SwingConstants.LEFT);
		REG_NO_1.setForeground(Color.BLACK);
		REG_NO_1.setFont(new Font("Consolas", Font.BOLD, 40));
		REG_NO_1.setBounds(60, 230, 200, 50);
		panel_1_1.add(REG_NO_1);
		
		displayadmin(REG_NO);

		
		JPanel panel_1 = new JPanel();
		panel_1.setForeground(new Color(115, 38, 191));
		panel_1.setBorder(new TitledBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null), "User Details", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_1.setBounds(85, 220, 570, 480);
		f.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JPanel panel_1_1_1 = new JPanel();
		panel_1_1_1.setBackground(new Color(255, 255, 255));
		panel_1_1_1.setLayout(null);
		panel_1_1_1.setForeground(new Color(115, 38, 191));
		panel_1_1_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_1_1_1.setBounds(20, 31, 526, 368);
		panel_1.add(panel_1_1_1);
		
		JLabel SEM = new JLabel("Semester");
		SEM.setBounds(40, 240, 220, 30);
		panel_1_1_1.add(SEM);
		SEM.setHorizontalAlignment(SwingConstants.LEFT);
		SEM.setForeground(Color.BLACK);
		SEM.setFont(new Font("Consolas", Font.BOLD, 25));
		
		JLabel BRANCH = new JLabel("Branch");
		BRANCH.setBounds(40, 170, 220, 30);
		panel_1_1_1.add(BRANCH);
		BRANCH.setHorizontalAlignment(SwingConstants.LEFT);
		BRANCH.setForeground(Color.BLACK);
		BRANCH.setFont(new Font("Consolas", Font.BOLD, 25));
		
		JLabel NAME = new JLabel("Name");
		NAME.setBounds(40, 30, 220, 30);
		panel_1_1_1.add(NAME);
		NAME.setHorizontalAlignment(SwingConstants.LEFT);
		NAME.setFont(new Font("Consolas", Font.BOLD, 25));
		NAME.setForeground(new Color(0, 0, 0));
		
		JLabel REG_NO1 = new JLabel("Register Number");
		REG_NO1.setBounds(40, 100, 220, 30);
		panel_1_1_1.add(REG_NO1);
		REG_NO1.setHorizontalAlignment(SwingConstants.LEFT);
		REG_NO1.setForeground(Color.BLACK);
		REG_NO1.setFont(new Font("Consolas", Font.BOLD, 25));
		
		JLabel YEAR = new JLabel("Year");
		YEAR.setBounds(40, 310, 220, 30);
		panel_1_1_1.add(YEAR);
		YEAR.setHorizontalAlignment(SwingConstants.LEFT);
		YEAR.setForeground(Color.BLACK);
		YEAR.setFont(new Font("Consolas", Font.BOLD, 25));
		
		JButton Update = new JButton(" Update");
		Update.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\refresh.png"));
		Update.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		Update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new StructUserUpdate(REG_NO);
			}
		});
		Update.setFont(new Font("Tahoma", Font.BOLD, 20));
		Update.setForeground(new Color(0, 0, 70));
		Update.setBackground(new Color(255, 255, 255));
		Update.setBounds(20, 415, 255, 50);
		panel_1.add(Update);
		
		JButton btnSignout = new JButton(" Sign Out");
		btnSignout.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\logout.png"));
		btnSignout.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnSignout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new StructUserLogin();
				f.dispose();
			}
		});
		btnSignout.setForeground(new Color(0, 0, 70));
		btnSignout.setFont(new Font("Tahoma", Font.BOLD, 20));
		btnSignout.setBackground(new Color(255, 255, 255));
		btnSignout.setBounds(291, 415, 255, 50);
		panel_1.add(btnSignout);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\Logo-medium2.png"));
		lblNewLabel.setBounds(0, 0, 1366, 145);
		f.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 1388, 145);
		f.getContentPane().add(panel);
		panel.setLayout(null);
		
	    String dquery = "select * from STUDENTS where REG_NO='" + REG_NO + "';";
	    Class.forName("com.mysql.cj.jdbc.Driver");
	    java.sql.Connection con;
	    con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange", "root", "adish");
	    PreparedStatement st = con.prepareStatement(dquery);
	    ResultSet r = st.executeQuery();

	    if (r.next()) {
	        int reg = r.getInt(1);
	        String name = r.getString(2);
	        String branch = r.getString(3);
	        int sem = r.getInt(4);
	        int year = r.getInt(5);
		
	        JLabel lblName = new JLabel(": "+name);
	        lblName.setBounds(260, 31, 240, 30);
	        panel_1_1_1.add(lblName);
	        lblName.setHorizontalAlignment(SwingConstants.LEFT);
	        lblName.setForeground(Color.BLACK);
	        lblName.setFont(new Font("Consolas", Font.BOLD, 25));
		
	        JLabel lblBranch = new JLabel(": "+branch);
	        lblBranch.setBounds(260, 170, 240, 30);
	        panel_1_1_1.add(lblBranch);
	        lblBranch.setHorizontalAlignment(SwingConstants.LEFT);
	        lblBranch.setForeground(Color.BLACK);
	        lblBranch.setFont(new Font("Consolas", Font.BOLD, 25));
		
	        JLabel lLblRegno = new JLabel(": "+reg);
	        lLblRegno.setBounds(260, 100, 240, 30);
	        panel_1_1_1.add(lLblRegno);
	        lLblRegno.setHorizontalAlignment(SwingConstants.LEFT);
	        lLblRegno.setForeground(Color.BLACK);
	        lLblRegno.setFont(new Font("Consolas", Font.BOLD, 25));
		
	        JLabel lblSem = new JLabel(": "+sem);
	        lblSem.setBounds(260, 240, 240, 30);
	        panel_1_1_1.add(lblSem);
	        lblSem.setHorizontalAlignment(SwingConstants.LEFT);
	        lblSem.setForeground(Color.BLACK);
	        lblSem.setFont(new Font("Consolas", Font.BOLD, 25));
		
	        JLabel lblYear = new JLabel(": "+year);
	        lblYear.setBounds(260, 310, 240, 30);
	        panel_1_1_1.add(lblYear);
	        lblYear.setHorizontalAlignment(SwingConstants.LEFT);
	        lblYear.setForeground(Color.BLACK);
	        lblYear.setFont(new Font("Consolas", Font.BOLD, 25));
	        

	    } else {
			JOptionPane.showMessageDialog(f,"Incorrect Reg. no or Password","Alert",JOptionPane.WARNING_MESSAGE);
	    }

	    
	      JPanel gradientPanel = new JPanel() {
	            @Override
	            protected void paintComponent(Graphics g) {
	                super.paintComponent(g);
	                Graphics2D g2d = (Graphics2D) g.create();
	                int width = getWidth();
	                int height = getHeight();
	                GradientPaint gradient = new GradientPaint(0, 0, new Color(28, 181, 224), 0, height, new Color(0, 0, 70));
	                g2d.setPaint(gradient);
	                g2d.fillRect(0, 0, width, height);
	                g2d.dispose();
	            }
	        };
		gradientPanel.setBounds(0, 0, 1388, 768);
		f.getContentPane().add(gradientPanel);
		
		
		f.setVisible(true);
		f.setSize(1366,768);
	    f.setLocationRelativeTo(null);

	    
	}
}
