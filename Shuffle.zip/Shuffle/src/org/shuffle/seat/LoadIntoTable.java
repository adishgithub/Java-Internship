package org.shuffle.seat;
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class LoadIntoTable {
    private JTable table;

    public LoadIntoTable() {
        JFrame frame = new JFrame("Room Table");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
	    ImageIcon image = new ImageIcon("arrange-seat1.png");
	    frame.setIconImage(image.getImage());

        // Create a table model with column names
        DefaultTableModel tableModel = new DefaultTableModel();
        tableModel.setColumnIdentifiers(new Object[]{"Room Number", "Number of Seats"});

        // Create the table with the custom table model
        table = new JTable(tableModel);
        table.setDefaultRenderer(Object.class, new CustomTableCellRenderer());
        table.setRowHeight(30);

        // Add the table to a scroll pane
        JScrollPane scrollPane = new JScrollPane(table);
        frame.getContentPane().add(scrollPane);

        // Set the frame properties
        frame.setSize(400,600);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        // Load data into the table
        try {
            loadDataIntoTable();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadDataIntoTable() throws Exception {
        String dquery = "SELECT * FROM ROOM";
        Class.forName("com.mysql.cj.jdbc.Driver");
        Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange", "root", "adish");
        PreparedStatement statement = con.prepareStatement(dquery);
        ResultSet resultSet = statement.executeQuery();

        // Get the table model
        DefaultTableModel tableModel = (DefaultTableModel) table.getModel();

        // Add the data to the table model
        while (resultSet.next()) {
            String roomNumber = resultSet.getString("SEAT");
            int numOfSeats = resultSet.getInt("REG_NO");
            int roomNo = resultSet.getInt("ROOM_NO");

            tableModel.addRow(new Object[]{roomNumber, numOfSeats,roomNo});
        }

        resultSet.close();
        statement.close();
        con.close();
    }

    // Custom cell renderer for formatting cell appearance
    private static class CustomTableCellRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            Component cellComponent = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);

            // Apply custom background color to alternate rows
            if (row % 2 == 0) {
                cellComponent.setBackground(new Color(240, 240, 240));
            } else {
                cellComponent.setBackground(Color.WHITE);
            }

            return cellComponent;
        }
    }
}
