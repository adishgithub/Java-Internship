package org.shuffle.seat;

import javax.swing.*;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import java.awt.Cursor;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class OpeningPage {

	public OpeningPage() {
		
		JFrame f = new JFrame();
	    ImageIcon image = new ImageIcon("arrange-seat1.png");
	    f.setIconImage(image.getImage());
		f.getContentPane().setBackground(new Color(170, 111, 219));
		f.getContentPane().setForeground(Color.WHITE);
	    f.setSize(1366,768);  
	    f.getContentPane().setLayout(null);  
	    f.setLocationRelativeTo(null);
	    f.setUndecorated(true);
	    
	    JPanel gradientPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                int width = getWidth();
                int height = getHeight();
                GradientPaint gradient = new GradientPaint(0, 0, new Color(28, 181, 224), 0, height, new Color(0, 0, 70));
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, width, height);
                g2d.dispose();
                

            }
        };
        
        JButton AdminButton = new JButton("");
        AdminButton.setOpaque(false);
	    AdminButton.setBounds(130, 150, 500, 500);
	    gradientPanel.add(AdminButton);
	    AdminButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	    AdminButton.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		new StructAdminLogin();
	    		f.dispose();
	    	}
	    });
	    AdminButton.setBackground(new Color(28, 181, 224));
	    AdminButton.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\admin.png"));
	    AdminButton.setBorder(null);
	    
	    JButton UserButton = new JButton("");
	    UserButton.setOpaque(false);
	    UserButton.setBounds(740, 150, 500, 500);
	    gradientPanel.add(UserButton);
	    UserButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	    UserButton.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		new StructUserLogin();
	    		f.dispose();
	    	}
	    });
	    UserButton.setBackground(new Color(28, 181, 224));
	    UserButton.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\user.png"));
	    UserButton.setBorder(null);
	    
	    JLabel lblNewLabel_1 = new JLabel("Admin Login");
	    lblNewLabel_1.setForeground(SystemColor.window);
	    lblNewLabel_1.setBounds(266, 650, 239, 30);
	    gradientPanel.add(lblNewLabel_1);
	    lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
	    lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 18));
	    
	    JLabel lblNewLabel_1_1 = new JLabel("User Login");
	    lblNewLabel_1_1.setForeground(SystemColor.window);
	    lblNewLabel_1_1.setBounds(870, 650, 239, 30);
	    gradientPanel.add(lblNewLabel_1_1);
	    lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
	    lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 18));
	    
		JButton btnClose = new JButton("");
		btnClose.setOpaque(false);
		btnClose.setBorder(null);
		btnClose.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});
		btnClose.setBackground(new Color(28, 181, 224));
		btnClose.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\cancel.png"));
		btnClose.setBounds(1315, 10, 40, 25);
		f.getContentPane().add(btnClose);
		
		
		gradientPanel.setBounds(0, 0, 1388, 768);
	    f.getContentPane().add(gradientPanel);
	    gradientPanel.setLayout(null);

	    
	    	    
	    	    
	    f.setVisible(true);  
		f.setResizable(false);

	}
}
