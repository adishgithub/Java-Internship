package org.shuffle.seat;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JProgressBar;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Cursor;
import javax.swing.SwingConstants;

public class Loading extends JFrame  {

	private JPanel contentPane;
    private JProgressBar pbar;
	private JLabel perc ;
	private JLabel lblNewLabel_1;
	private JLabel lblNewLabel_2;
	private JPanel panel;
	private JPanel panel_1;
	private JLabel lblNewLabel_4;
	
	public static void main(String[] args) {
		
				try {
					
					Loading a = new Loading();
					a.setVisible(true);
					a.setLocationRelativeTo(null);

                      try {
					  for(int i=1;i<=100;i++) {
						  a.pbar.setValue(i);
						  Thread.sleep(10);
						
						 a.perc.setText(String.valueOf(i)+"%");
					      if(i==100) {
					    	 a.setVisible(false);
					    	  
					      }
					  
					  }
					 
					} catch (Exception e) {
					e.printStackTrace();
				}
                      new OpeningPage();
                      try {                    
                    	  FetchStudentsByBranch f = new FetchStudentsByBranch();
                    	  f.storeIntoArray();
                    	  RoomManagement roomManagement = new RoomManagement();
                    	  roomManagement.insertRecordsIntoTemporaryTable(FetchStudentsByBranch.Rooms);}
                      catch(Exception e) {
                    	  
                      }


			}catch(Exception h) {
				
			}
			;
		   
			
		
	}

	



	public Loading() {
		setUndecorated(true);
		setTitle("EDUSOFT");
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 728, 500);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		 
		 panel_1 = new JPanel();
		 panel_1.setBackground(new Color(255, 255, 255));
		 panel_1.setBounds(0, 0, 728, 500);
		 contentPane.add(panel_1);
		 panel_1.setLayout(null);
		 
		 JLabel lblNewLabel = new JLabel("");
		 lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		 lblNewLabel.setBounds(117, 55, 443, 271);
		 panel_1.add(lblNewLabel);
		 lblNewLabel.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\Logo-medium.png"));
		 
		 lblNewLabel_1 = new JLabel("WELCOME");
		 lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		 lblNewLabel_1.setBounds(276, 332, 186, 32);
		 panel_1.add(lblNewLabel_1);
		 lblNewLabel_1.setFont(new Font("STZhongsong", Font.BOLD, 25));
		 
		 lblNewLabel_4 = new JLabel("");
		 lblNewLabel_4.setToolTipText("exit");
		 lblNewLabel_4.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		 lblNewLabel_4.addMouseListener(new MouseAdapter() {
		 	@Override
		 	public void mouseClicked(MouseEvent e) {
		 		System.exit(0);
		 	}
		 });
		 lblNewLabel_4.setIcon(new ImageIcon("C:\\Users\\anasa\\Downloads\\delete.png"));
		 lblNewLabel_4.setBounds(679, 11, 26, 38);
		 panel_1.add(lblNewLabel_4);
		 
		 panel = new JPanel();
		 panel.setBounds(0, 413, 728, 87);
		 panel_1.add(panel);
		 panel.setBackground(new Color(28, 181, 224));
		 panel.setLayout(null);
		 
		 perc = new JLabel("0%");
		 perc.setForeground(new Color(255, 255, 255));
		 perc.setBounds(326, 90, 53, 14);
		 panel.add(perc);
		 perc.setFont(new Font("Tahoma", Font.BOLD, 17));
		 
		  pbar = new JProgressBar();
		  pbar.setBounds(10, 54, 708, 22);
		  panel.add(pbar);
		  
		  lblNewLabel_2 = new JLabel("LOADING...");
		  lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		  lblNewLabel_2.setForeground(new Color(255, 255, 255));
		  lblNewLabel_2.setBounds(295, 11, 118, 32);
		  panel.add(lblNewLabel_2);
		  lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 17));
	
		
		 
		
		
		
		
	}
}
