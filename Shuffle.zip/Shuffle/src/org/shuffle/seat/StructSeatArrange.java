package org.shuffle.seat;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JPanel;
import java.awt.Font;
import javax.swing.border.TitledBorder;
import javax.swing.border.BevelBorder;



public class StructSeatArrange {
	
	JFrame f;
	JPanel panel,panel2;

	public StructSeatArrange() {
	
		

		f = new JFrame("StructSeatArrenge");  
		f.getContentPane().setBackground(new Color(115, 38, 191));
	    ImageIcon image = new ImageIcon("arrange-seat1.png");
	    f.setIconImage(image.getImage());
		
	    f.setUndecorated(true);
		f.getContentPane().setLayout(null);
		
		// TODO Auto-generated constructor stub
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});
		btnNewButton.setBackground(new Color(242, 242, 242));
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\cancel.png"));
		btnNewButton.setBounds(1326, 11, 30, 30);
		f.getContentPane().add(btnNewButton);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\arrange (1) (3).png"));
		lblNewLabel.setBounds(0, 0, 1366, 145);
		f.getContentPane().add(lblNewLabel);
		
		panel = new JPanel();
		panel.setBounds(0, 0, 1388, 145);
		f.getContentPane().add(panel);
		
		panel2 = new JPanel();
		panel2.setForeground(new Color(115, 38, 191));
		panel2.setBorder(new TitledBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null), "Admin Details", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel2.setBounds(40, 185, 480, 190);
		f.getContentPane().add(panel2);
		panel2.setLayout(null);
		
		JLabel NAME = new JLabel("No. of Students");
		NAME.setBounds(30, 30, 200, 30);
		panel2.add(NAME);
		NAME.setHorizontalAlignment(SwingConstants.LEFT);
		NAME.setFont(new Font("Consolas", Font.BOLD, 20));
		NAME.setForeground(new Color(0, 0, 0));
		
		JLabel REG_NO1 = new JLabel("No of Rooms");
		REG_NO1.setBounds(30, 70, 220, 30);
		panel2.add(REG_NO1);
		REG_NO1.setHorizontalAlignment(SwingConstants.LEFT);
		REG_NO1.setForeground(Color.BLACK);
		REG_NO1.setFont(new Font("Consolas", Font.BOLD, 20));
		
		JLabel REG_NO1_1 = new JLabel("No of Branches");
		REG_NO1_1.setHorizontalAlignment(SwingConstants.LEFT);
		REG_NO1_1.setForeground(Color.BLACK);
		REG_NO1_1.setFont(new Font("Consolas", Font.BOLD, 20));
		REG_NO1_1.setBounds(30, 110, 220, 30);
		panel2.add(REG_NO1_1);
		
		JLabel REG_NO1_1_1 = new JLabel("No of Seats");
		REG_NO1_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		REG_NO1_1_1.setForeground(Color.BLACK);
		REG_NO1_1_1.setFont(new Font("Consolas", Font.BOLD, 20));
		REG_NO1_1_1.setBounds(30, 150, 220, 30);
		panel2.add(REG_NO1_1_1);
		
		
		f.setVisible(true);
		f.setSize(1366,768);
	    f.setLocationRelativeTo(null);
	    

	    
	}
}

