package org.shuffle.seat;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.JTextArea;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;


public class StructUserSignUp {
	private JTextField tfName;
	private JPasswordField PAS1;
	private JTextField tfSemester;
	private JTextField tfYear;

	public StructUserSignUp() {
		// TODO Auto-generated constructor stub
		JFrame f = new JFrame("Login");  
		JLabel title,labReg;
		
	    ImageIcon image = new ImageIcon("arrange-seat1.png");
	    f.setIconImage(image.getImage());
	    f.setUndecorated(true);
	    
	    JTextField tfREG_NO; JPasswordField PAS2;
	    
	    JButton btnMinimize = new JButton("");
	    btnMinimize.setOpaque(false);
	    btnMinimize.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		f.setState(f.ICONIFIED);
	    	}
	    });
	    
	    JButton btnNewButton = new JButton("");
	    btnNewButton.setOpaque(false);
	    btnNewButton.setBorder(null);
	    btnNewButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	    btnNewButton.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		f.dispose();
	    	}
	    });
	    btnNewButton.setBackground(new Color(242, 242, 242));
	    btnNewButton.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\cancel.png"));
	    btnNewButton.setBounds(1315, 10, 40, 25);
	    f.getContentPane().add(btnNewButton);
	    btnMinimize.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	    btnMinimize.setBorder(null);
	    btnMinimize.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\minimize-sign.png"));
	    btnMinimize.setBounds(1270, 10, 40, 25);
	    btnMinimize.setBackground(new Color(242, 242, 242));
	    f.getContentPane().add(btnMinimize);
	    
	    JLabel lblNewLabel = new JLabel("");
	    lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
	    lblNewLabel.setBounds(527, 164, 839, 390);
	    f.getContentPane().add(lblNewLabel);
	    lblNewLabel.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\Logo-Large.png"));
	    
	    JButton log;
	    f.setSize(1366,768);  
	    f.getContentPane().setLayout(null);  
	    f.setVisible(true);  
		f.setResizable(false);
		f.getContentPane().setBackground(new Color(170, 111, 219));
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(530, 0, 838, 768);
		f.getContentPane().add(panel);
		
		JLabel lblNewLabel_1 = new JLabel("I have an account");
		lblNewLabel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new StructUserLogin();
				f.dispose();
			}
		});
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setBounds(100, 705, 340, 30);
		f.getContentPane().add(lblNewLabel_1);
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(90, 58, 350, 650);
		f.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		title=new JLabel("Admin SignUp");
		title.setBounds(20, 20, 310, 40);
		panel_1.add(title);
		title.setForeground(new Color(42, 13, 66));
		title.setHorizontalAlignment(SwingConstants.CENTER);
		title.setFont(new Font("Arial", Font.BOLD, 30));
		labReg = new JLabel("Register No");
		labReg.setBounds(50, 70, 150, 30);
		panel_1.add(labReg);
		labReg.setForeground(new Color(42, 13, 66));
		labReg.setFont(new Font("Arial", Font.PLAIN, 15));
		labReg.setHorizontalAlignment(SwingConstants.LEFT);
		tfREG_NO = new JTextField();
		tfREG_NO.setBounds(40, 100, 270, 35);
		panel_1.add(tfREG_NO);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(50, 140, 150, 30);
		panel_1.add(lblName);
		lblName.setHorizontalAlignment(SwingConstants.LEFT);
		lblName.setForeground(new Color(42, 13, 66));
		lblName.setFont(new Font("Arial", Font.PLAIN, 15));
		
		tfName = new JTextField();
		tfName.setBounds(40, 170, 270, 35);
		panel_1.add(tfName);
		
		JLabel lblName_1 = new JLabel("Branch");
		lblName_1.setBounds(50, 210, 146, 40);
		panel_1.add(lblName_1);
		lblName_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblName_1.setForeground(new Color(42, 13, 66));
		lblName_1.setFont(new Font("Arial", Font.PLAIN, 15));
		
		JComboBox tfBranch = new JComboBox();
		tfBranch.setBounds(40, 240, 270, 35);
		panel_1.add(tfBranch);
		tfBranch.setMaximumRowCount(5);
		tfBranch.setModel(new DefaultComboBoxModel(new String[] {"C S E","E C E","M E","C E","E E E"}));
		
		JLabel lblName_1_1 = new JLabel("Semester");
		lblName_1_1.setBounds(50, 280, 146, 40);
		panel_1.add(lblName_1_1);
		lblName_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblName_1_1.setForeground(new Color(42, 13, 66));
		lblName_1_1.setFont(new Font("Arial", Font.PLAIN, 15));
		
		tfSemester = new JTextField();
		tfSemester.setBounds(40, 310, 270, 35);
		panel_1.add(tfSemester);
		
		JLabel lblName_1_1_1 = new JLabel("Year");
		lblName_1_1_1.setBounds(50, 350, 146, 40);
		panel_1.add(lblName_1_1_1);
		lblName_1_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblName_1_1_1.setForeground(new Color(42, 13, 66));
		lblName_1_1_1.setFont(new Font("Arial", Font.PLAIN, 15));
		
		tfYear = new JTextField();
		tfYear.setBounds(40, 380, 270, 35);
		panel_1.add(tfYear);
		
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setBounds(50, 420, 146, 40);
		panel_1.add(lblPassword);
		lblPassword.setHorizontalAlignment(SwingConstants.LEFT);
		lblPassword.setForeground(new Color(42, 13, 66));
		lblPassword.setFont(new Font("Arial", Font.PLAIN, 15));
		
		PAS1 = new JPasswordField();
		PAS1.setBounds(40, 450, 270, 35);
		panel_1.add(PAS1);
		
		JLabel lblPassword_1 = new JLabel("Confirm Password");
		lblPassword_1.setBounds(50, 490, 146, 40);
		panel_1.add(lblPassword_1);
		lblPassword_1.setForeground(new Color(42, 13, 66));
		lblPassword_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblPassword_1.setFont(new Font("Arial", Font.PLAIN, 15));
		
		PAS2 = new JPasswordField();
		PAS2.setBounds(40, 520, 270, 35);
		panel_1.add(PAS2);
		log = new JButton(" SignUp");
		log.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\user (1).png"));
		log.setBounds(40, 580, 270, 40);
		panel_1.add(log);
		log.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				
				if (!(new String(PAS1.getPassword()).equals(new String(PAS2.getPassword()))))
	    		{
	    			JOptionPane.showMessageDialog(f,"You Password Does not Match!","Alert",JOptionPane.WARNING_MESSAGE);
	    		}else {
	    			try {	
	    				Class.forName("com.mysql.cj.jdbc.Driver"); 
	    				java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange","root","adish");
	    				
	    				// Check if REG_NO already exists in the database
	    				String checkQuery = "SELECT REG_NO FROM STUDENTS WHERE REG_NO = ?";
	    				PreparedStatement checkPs = con.prepareStatement(checkQuery);
	    				checkPs.setString(1, tfREG_NO.getText());
	    				ResultSet resultSet = checkPs.executeQuery();
	    				
	    				if (resultSet.next()) {
	    					// REG_NO already exists
	    					JOptionPane.showMessageDialog(f, "Register number already exists!", "Alert", JOptionPane.WARNING_MESSAGE);
	    				} else {
	    					// Proceed with inserting the data
	    					String insertQuery = "INSERT INTO STUDENTS (REG_NO,NAME,BRANCH,SEMESTER,YEAR,PASSWORD) VALUES(?,?,?,?,?,?)";
	    					PreparedStatement insertPs = con.prepareStatement(insertQuery);
	    					
	    					// Set the parameter values for insertion
	    					insertPs.setString(1, tfREG_NO.getText());
	    					insertPs.setString(2, tfName.getText());
	    					insertPs.setString(3, (String) tfBranch.getSelectedItem());
	    					insertPs.setString(4, tfSemester.getText());
	    					insertPs.setString(5, tfYear.getText());
	    					insertPs.setString(6, PAS1.getText());
	    					
	    					int result = insertPs.executeUpdate();
	    					if (result == 1) {
	    						JOptionPane.showMessageDialog(f, "Account Created!", "Welcome", JOptionPane.PLAIN_MESSAGE);
	    					} else {
	    						JOptionPane.showMessageDialog(f, "Something Went Wrong", "Alert", JOptionPane.ERROR_MESSAGE);
	    						tfREG_NO.setText("");
	    						PAS2.setText("");
	    					}
	    				}
	    			} catch (Exception e) {
	    				System.out.println(e.getMessage());
	    			}
	    			try {	
	    			    Class.forName("com.mysql.cj.jdbc.Driver"); 
	    			    java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange","root","adish");

	    			    // Check if REG_NO already exists in the database
	    			    String checkQuery = "SELECT REG_NO FROM STUDENTS WHERE REG_NO = ?";
	    			    PreparedStatement checkPs = con.prepareStatement(checkQuery);
	    			    checkPs.setString(1, tfREG_NO.getText());
	    			    ResultSet resultSet = checkPs.executeQuery();

	    			    if (resultSet.next()) {
	    			        // REG_NO already exists
	    			        JOptionPane.showMessageDialog(f, "Register number already exists!", "Alert", JOptionPane.WARNING_MESSAGE);
	    			    } else {
	    			        // Proceed with inserting the data
	    			        String insertQuery = "INSERT INTO STUDENTS (REG_NO,NAME,BRANCH,SEMESTER,YEAR,PASSWORD) VALUES(?,?,?,?,?,?)";
	    			        PreparedStatement insertPs = con.prepareStatement(insertQuery);
	    			        
	    			        // Set the parameter values for insertion
	    			        insertPs.setString(1, tfREG_NO.getText());
	    			        insertPs.setString(2, tfName.getText());
	    			        insertPs.setString(3, (String) tfBranch.getSelectedItem());
	    			        insertPs.setString(4, tfSemester.getText());
	    			        insertPs.setString(5, tfYear.getText());
	    			        insertPs.setString(6, PAS1.getText());

	    			        int result = insertPs.executeUpdate();
	    			        if (result == 1) {
	    			            JOptionPane.showMessageDialog(f, "Account Created!", "Welcome", JOptionPane.PLAIN_MESSAGE);
	    			        } else {
	    			            JOptionPane.showMessageDialog(f, "Something Went Wrong", "Alert", JOptionPane.ERROR_MESSAGE);
	    			            tfREG_NO.setText("");
	    			            PAS2.setText("");
	    			        }
	    			    }
	    			} catch (Exception e) {
	    			    System.out.println(e.getMessage());
	    			}
	    		}
			}
		});
		log.setFont(new Font("Tahoma", Font.BOLD, 17));
		log.setBackground(new Color(0, 0, 70));
		log.setForeground(new Color(255, 255, 255));
		log.setBorderPainted(false);
		
	    JPanel gradientPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                int width = getWidth();
                int height = getHeight();
                GradientPaint gradient = new GradientPaint(0, 0, new Color(28, 181, 224), 0, height, new Color(0, 0, 70));
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, width, height);
                g2d.dispose();
            }
        };
	    gradientPanel.setBounds(0, 0, 1388, 768);
	    f.getContentPane().add(gradientPanel);
	    gradientPanel.setLayout(null);

	    f.setLocationRelativeTo(null);
	}
}
