package org.shuffle.seat;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import java.awt.Color;
import java.awt.Font;

public class RetrieveDataAndSaveToFile extends JFrame {
    private JTextArea textArea;

    public RetrieveDataAndSaveToFile() {
        // Create the JTextArea
        textArea = new JTextArea();
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setBounds(10, 10, 400, 385);
        getContentPane().add(scrollPane);

        // Create the Retrieve Data button
        JButton retrieveButton = new JButton(" Retrieve Data");
        retrieveButton.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\view.png"));
        retrieveButton.setFont(new Font("Tahoma", Font.BOLD, 15));
        retrieveButton.setBackground(new Color(255, 255, 255));
        retrieveButton.setBounds(10, 406, 190, 44);
        retrieveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                retrieveDataAndDisplay();
            }
        });
        getContentPane().add(retrieveButton);

        // Create the Save Data button
        JButton saveButton = new JButton(" Save Data");
        saveButton.setBackground(new Color(255, 255, 255));
        saveButton.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\diskette.png"));
        saveButton.setFont(new Font("Tahoma", Font.BOLD, 15));
        saveButton.setBounds(210, 406, 200, 44);
        saveButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveDataToFile();
            }
        });
        getContentPane().add(saveButton);
        ImageIcon image = new ImageIcon("arrange-seat1.png");
	    setIconImage(image.getImage());

        // Set JFrame properties
        setSize(440,500);
        setTitle("Data Retrieval and Saving");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);
        setVisible(true);
	    setLocationRelativeTo(null);

    }

    public void retrieveDataAndDisplay() {
        try {
            // Establish the database connection
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange", "root", "adish");
            String sql = "SELECT * FROM ROOM";
            Statement statement = conn.prepareStatement(sql);
            // Execute the SQL query
            
            ResultSet resultSet = statement.executeQuery(sql);

            // Clear the text area
            textArea.setText("SEAT\tREG_NO\tROOM_NO");

            // Iterate over the result set and append data to the text area
            while (resultSet.next()) {
                String row = "\n"+resultSet.getString("SEAT") + "\t" + resultSet.getString("REG_NO") + "\t"
                        + resultSet.getString("ROOM_NO") + "\n";
                textArea.append(row);
            }

            // Close the resources
            resultSet.close();
            statement.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void saveDataToFile() {
        JFileChooser fileChooser = new JFileChooser();
        int option = fileChooser.showSaveDialog(this);

        if (option == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();

            try {
                BufferedWriter writer = new BufferedWriter(new FileWriter(file));
                writer.write(textArea.getText());
                writer.close();

                JOptionPane.showMessageDialog(this, "Data has been saved to file successfully.");

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}
