package org.shuffle.seat;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class RoomManagement {
    private static Connection connection;
    public RoomManagement() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange", "root", "adish");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    
    public void insertRecordsIntoTemporaryTable(List<String> Rooms) {
        String insertRecordSQL = "INSERT INTO temporary_table (room_name, room_no) VALUES (?, ?)";

        try {
            PreparedStatement preparedStatement = connection.prepareStatement(insertRecordSQL);
            int roomNo = 1; // Start with room number 1

            for (String record : Rooms) {
                preparedStatement.setString(1, record);
                preparedStatement.setInt(2, roomNo);
                preparedStatement.executeUpdate();
                roomNo++; // Increment room number after each record insertion
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
	public static void printTableValues() {
        String selectRecordsSQL = "SELECT * FROM temporary_table";

        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(selectRecordsSQL);

            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();

            while (resultSet.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    String columnValue = resultSet.getString(i);
                    System.out.print(columnValue + "\t");
                }
                System.out.println();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
