package org.shuffle.seat;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JPanel;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import javax.swing.UIManager; 
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.Cursor;


public class StructUserUpdate{
	private JTextField tfNAME;
	private JTextField tfREG_NO;
	private JTextField tfSEM;
	private JTextField tfYEAR;
	private JPasswordField PAS1;
	private JPasswordField PAS2;
	
	public StructUserUpdate(String REG_NO){
		
		JFrame f = new JFrame("Login");  
		f.getContentPane().setBackground(new Color(115, 38, 191));
	    ImageIcon image = new ImageIcon("arrange-seat1.png");
	    f.setIconImage(image.getImage());
		
	    f.setUndecorated(true);
		f.getContentPane().setLayout(null);
		
		
		// TODO Auto-generated constructor stub
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setOpaque(false);
		btnNewButton.setBorder(null);
		btnNewButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});
		
		JButton btnMinimize = new JButton("");
		btnMinimize.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.setState(f.ICONIFIED);
			}
		});
		btnMinimize.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnMinimize.setBorder(null);
		btnMinimize.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\minimize-sign.png"));
		btnMinimize.setBounds(1270, 10, 40, 25);
		btnMinimize.setBackground(new Color(242, 242, 242));
		f.getContentPane().add(btnMinimize);
		btnNewButton.setBackground(new Color(242, 242, 242));
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\cancel.png"));
		btnNewButton.setBounds(1315, 10, 40, 25);
		f.getContentPane().add(btnNewButton);
		
		JPanel panel_1 = new JPanel();
		panel_1.setForeground(new Color(115, 38, 191));
		panel_1.setBorder(new TitledBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null), "Update Details", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_1.setBounds(50, 90, 520, 610);
		f.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		JPanel panel_1_1_1 = new JPanel();
		panel_1_1_1.setLayout(null);
		panel_1_1_1.setForeground(new Color(115, 38, 191));
		panel_1_1_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_1_1_1.setBounds(20, 30, 480, 500);
		panel_1.add(panel_1_1_1);
		
		JLabel SEM = new JLabel("Semester");
		SEM.setBounds(20, 240, 220, 30);
		panel_1_1_1.add(SEM);
		SEM.setHorizontalAlignment(SwingConstants.LEFT);
		SEM.setForeground(Color.BLACK);
		SEM.setFont(new Font("Consolas", Font.BOLD, 25));
		
		JLabel BRANCH = new JLabel("Branch");
		BRANCH.setBounds(20, 170, 220, 30);
		panel_1_1_1.add(BRANCH);
		BRANCH.setHorizontalAlignment(SwingConstants.LEFT);
		BRANCH.setForeground(Color.BLACK);
		BRANCH.setFont(new Font("Consolas", Font.BOLD, 25));
		
		JLabel NAME = new JLabel("Name");
		NAME.setBounds(20, 30, 220, 30);
		panel_1_1_1.add(NAME);
		NAME.setHorizontalAlignment(SwingConstants.LEFT);
		NAME.setFont(new Font("Consolas", Font.BOLD, 25));
		NAME.setForeground(new Color(0, 0, 0));
		
		JLabel REG_NO1 = new JLabel("Register Number");
		REG_NO1.setBounds(20, 100, 220, 30);
		panel_1_1_1.add(REG_NO1);
		REG_NO1.setHorizontalAlignment(SwingConstants.LEFT);
		REG_NO1.setForeground(Color.BLACK);
		REG_NO1.setFont(new Font("Consolas", Font.BOLD, 25));
		
		JLabel YEAR = new JLabel("Year");
		YEAR.setBounds(20, 310, 220, 30);
		panel_1_1_1.add(YEAR);
		YEAR.setHorizontalAlignment(SwingConstants.LEFT);
		YEAR.setForeground(Color.BLACK);
		YEAR.setFont(new Font("Consolas", Font.BOLD, 25));
		
		tfNAME = new JTextField();
		tfNAME.setBounds(250, 20, 210, 40);
		panel_1_1_1.add(tfNAME);
		tfNAME.setColumns(10);
		
		tfREG_NO = new JTextField();
		tfREG_NO.setColumns(10);
		tfREG_NO.setBounds(250, 90, 210, 40);
		panel_1_1_1.add(tfREG_NO);
		
		tfREG_NO.setText(REG_NO);
		tfREG_NO.setEditable(false);
		
		JComboBox tfBranch = new JComboBox();
		tfBranch.setMaximumRowCount(5);
		tfBranch.setModel(new DefaultComboBoxModel(new String[] {"C S E","E C E","M E","C E","E E E"}));
		tfBranch.setBounds(250, 160, 210, 40);
		panel_1_1_1.add(tfBranch);
		
		tfSEM = new JTextField();
		tfSEM.setColumns(10);
		tfSEM.setBounds(250, 230, 210, 40);
		panel_1_1_1.add(tfSEM);
		
		tfYEAR = new JTextField();
		tfYEAR.setColumns(10);
		tfYEAR.setBounds(250, 300, 210, 40);
		panel_1_1_1.add(tfYEAR);
		
		JLabel lblNewPassword = new JLabel("New Password");
		lblNewPassword.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewPassword.setForeground(Color.BLACK);
		lblNewPassword.setFont(new Font("Consolas", Font.BOLD, 25));
		lblNewPassword.setBounds(20, 380, 220, 30);
		panel_1_1_1.add(lblNewPassword);
		
		PAS1 = new JPasswordField();
		PAS1.setBounds(250, 370, 210, 40);
		panel_1_1_1.add(PAS1);
		
		JLabel lblConfirmPassword = new JLabel("ConfirmPassword");
		lblConfirmPassword.setHorizontalAlignment(SwingConstants.LEFT);
		lblConfirmPassword.setForeground(Color.BLACK);
		lblConfirmPassword.setFont(new Font("Consolas", Font.BOLD, 25));
		lblConfirmPassword.setBounds(20, 450, 220, 30);
		panel_1_1_1.add(lblConfirmPassword);
		
		PAS2 = new JPasswordField();
		PAS2.setBounds(250, 440, 210, 40);
		panel_1_1_1.add(PAS2);
		
		JButton Update = new JButton(" Update");
		Update.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\refresh (1).png"));
		Update.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		Update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				
				if (!(new String(PAS1.getPassword()).equals(new String(PAS2.getPassword()))))
	    		{
	    			JOptionPane.showMessageDialog(f,"You Password Does not Match!","Alert",JOptionPane.WARNING_MESSAGE);
	    		}else {
	    			String query = "UPDATE STUDENTS SET REG_NO = ?, NAME = ?, BRANCH = ?, SEMESTER = ?, YEAR = ?, PASSWORD = ? WHERE REG_NO = ?";
	    			try {
	    			    Class.forName("com.mysql.cj.jdbc.Driver"); 
	    			    Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange","root","adish");
	    			    
	    			    PreparedStatement ps = con.prepareStatement(query);
	    			    ps.setString(1, tfREG_NO.getText());
	    			    ps.setString(2, tfNAME.getText());
	    			    ps.setString(3, (String) tfBranch.getSelectedItem());
	    			    ps.setString(4, tfSEM.getText());
	    			    ps.setString(5, tfYEAR.getText());
	    			    ps.setString(6, PAS1.getText());
	    			    ps.setString(7, REG_NO); // Assuming REG_NO is the column name for comparison
	    			    
	    			    int result = ps.executeUpdate();
	    			    if (result == 1) {
	    			        JOptionPane.showMessageDialog(f, "Something Went Wrong", "Alert", JOptionPane.ERROR_MESSAGE);
	    			        f.dispose();
	    			        
	    			    } else {
	    			        JOptionPane.showMessageDialog(f, "Account Updated!!", "Success", JOptionPane.PLAIN_MESSAGE);
	    			        f.dispose();

	    			    }
	    			    
	    			    con.close();
	    			} catch (Exception e) {
	    			    System.out.println(e.getMessage());
	    			}
	    		}
			}
		});
		Update.setFont(new Font("Tahoma", Font.BOLD, 20));
		Update.setForeground(new Color(255, 255, 255));
		Update.setBackground(new Color(0, 0, 70));
		Update.setBounds(20, 545, 480, 40);
		panel_1.add(Update);
		
		JPanel panel_3 = new JPanel();
		panel_3.setBounds(640, 0, 748, 768);
		f.getContentPane().add(panel_3);
		panel_3.setLayout(null);
		
	    JPanel gradientPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                int width = getWidth();
                int height = getHeight();
                GradientPaint gradient = new GradientPaint(0, 0, new Color(28, 181, 224), 0, height, new Color(0, 0, 70));
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, width, height);
                g2d.dispose();
            }
        };
	gradientPanel.setBounds(0, 0, 1388, 768);
	f.getContentPane().add(gradientPanel);
	gradientPanel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\Logo-Large.png"));
		lblNewLabel.setBounds(0, 234, 738, 265);
		panel_3.add(lblNewLabel);
		f.setVisible(true);
		f.setSize(1366,768);
	    f.setLocationRelativeTo(null);
	    

	    
	}
}
