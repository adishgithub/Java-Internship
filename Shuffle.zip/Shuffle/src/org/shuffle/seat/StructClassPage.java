package org.shuffle.seat;

import java.awt.Color;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.TableModel;

import net.proteanit.sql.DbUtils;

import javax.swing.border.EtchedBorder;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.SystemColor;
import javax.swing.JTable;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.border.EmptyBorder;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class StructClassPage extends JFrame {
    
    private JFrame f;  
    private JTextField tfnumberofstudents;
    private JTextField RoomNo;
    private JTextField tfnumberofseats;
    private JTextField tfnumberofrooms;
    private JTable table;
    private JTextField seatperrooms;
    private JComboBox cbcol,cbrow;
    private JPanel panel_1_1_1;
    private String numOfSeat,limit1,limit2,limit3,limit4,limit5; 
    private JComboBox SelectRoom;
	private String regNo,SEAT;

    
    Connection con;
	PreparedStatement pst;
    PreparedStatement st;
	ResultSet rs,rs1;
	private JTable table2;
    
	public void connect() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		    con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange", "root", "adish");
		}catch (ClassNotFoundException | SQLException ex) {
		}
	}
	
	public void delete() {
		String query = "DELETE FROM ROOM WHERE SEAT = ?";
		try {	
    		Class.forName("com.mysql.cj.jdbc.Driver"); 
    		java.sql.Connection con;
    		con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange","root","adish");			    		
		    PreparedStatement ps = con.prepareStatement(query);  	    		
    		ps.setString(1,SEAT); // Assuming REG_NO is the column name for comparison
    		int result = ps.executeUpdate();
		}catch(Exception e1) {
    		System.out.println(e1.getMessage());
    	}
	}
	
	public void reset() {
		String query = "ALTER TABLE ROOM AUTO_INCREMENT = 1;";
		try {	
    		Class.forName("com.mysql.cj.jdbc.Driver"); 
    		java.sql.Connection con;
    		con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange","root","adish");			    		
		    PreparedStatement ps = con.prepareStatement(query);  	    		
    		int result = ps.executeUpdate();
		}catch(Exception e1) {
    		System.out.println(e1.getMessage());
    	}
	}
	
    public void updateNumberOfStudents() {
        String sql = "SELECT COUNT(*) AS total FROM STUDENTS";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange", "root", "adish");
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                int totalCount = rs.getInt("total");
                tfnumberofstudents.setText(String.valueOf(totalCount));
            }
        } catch (Exception e) {
            e.printStackTrace();
            // or
            System.err.println("Error: " + e.getMessage());
        }
    }
    
    public void addToRooms() {
    	try {	
			Class.forName("com.mysql.cj.jdbc.Driver"); 
			java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange","root","adish");
			
			// Check if REG_NO already exists in the database
			String checkQuery = "SELECT REG_NO FROM ROOM WHERE REG_NO = ?";
			PreparedStatement checkPs = con.prepareStatement(checkQuery);
			checkPs.setString(1, regNo);
			ResultSet resultSet = checkPs.executeQuery();
			
			if (resultSet.next()) {
				// REG_NO already exists
				JOptionPane.showMessageDialog(f, "Register number already exists!", "Alert", JOptionPane.WARNING_MESSAGE);
			} else {
				// Proceed with inserting the data
				String insertQuery = "INSERT INTO ROOM (REG_NO,ROOM_NO) VALUES(?,?)";
				PreparedStatement insertPs = con.prepareStatement(insertQuery);
				
				// Set the parameter values for insertion
				insertPs.setString(1, regNo);
				insertPs.setString(2, (String) SelectRoom.getSelectedItem());
				
				int result = insertPs.executeUpdate();
				if (result == 1) {
				} else {

				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
    }

    public void updateTotalNumberOfSeats() {
        String sql = "SELECT SUM(NUM_OF_SEAT) AS total FROM ROOMS";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange", "root", "adish");
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                int totalSeats = rs.getInt("total");
                tfnumberofseats.setText(String.valueOf(totalSeats));
            }
        } catch (Exception e) {
            e.printStackTrace();
            // or
            System.err.println("Error: " + e.getMessage());
        }
    }

    public void updateNumberOfRooms() {
        String sql = "SELECT COUNT(*) AS total FROM ROOMS";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange", "root", "adish");
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                int totalCount = rs.getInt("total");
                tfnumberofrooms.setText(String.valueOf(totalCount));
            }
        } catch (Exception e) {
            e.printStackTrace();
            // or
            System.err.println("Error: " + e.getMessage());
        }
    }
    
    public void updateCounts() {
        updateNumberOfStudents();
        updateTotalNumberOfSeats();
        updateNumberOfRooms();
    }
    
    public void deleteRoom() {
        String selectedRoom = SelectRoom.getSelectedItem().toString();

        String sql = "DELETE FROM ROOMS WHERE ROOM_NO = ?";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange", "root", "adish");
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, selectedRoom);

            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Room deleted successfully");
    			SelectRoom.removeAllItems();
                populateRoomComboBox();
            } else {
                JOptionPane.showMessageDialog(null, "Failed to delete room");
            }
        } catch (Exception e) {
            e.printStackTrace();
            // or
            System.err.println("Error: " + e.getMessage());
        }
    }
    
    public void retrieveNumOfSeatsForRoom() {
        String selectedRoom = SelectRoom.getSelectedItem().toString();

        // Prepare the SQL query with the updated column name
        String sql = "SELECT NUM_OF_SEAT FROM ROOMS WHERE ROOM_NO = ?";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange", "root", "adish");
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, selectedRoom);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                // Get the NUM_OF_SEAT value from the result set with the updated column name
                String numOfSeat = rs.getString("NUM_OF_SEAT");
                seatperrooms.setText(numOfSeat);
            } else {
                // Handle the case when the selected room is not found in the database
                seatperrooms.setText("Room not found");
            }

        } catch (Exception e1) {
            e1.printStackTrace();
            // or
            System.err.println("Error: " + e1.getMessage());
        }
    }


    
    public void populateRoomComboBox() {
        String sql = "SELECT * FROM ROOMS";
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange", "root", "adish");
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                SelectRoom.addItem(rs.getString("ROOM_NO"));
            }
        } catch (Exception e) {
            e.printStackTrace();
            // or
            System.err.println("Error: " + e.getMessage());
        }
    }

	public void loadDataIntoTable() {
		try {
		    pst = con.prepareStatement("SELECT REG_NO  FROM temporary_table");
		    rs = pst.executeQuery();
		    table.setModel(DbUtils.resultSetToTableModel(rs));
		} catch (SQLException e) {
		    // Handle the exception appropriately (e.g., log the error, show an error message)
		    e.printStackTrace();
		}
	}
    
	public void loadDataIntoTable2() {
		try {
		    pst = con.prepareStatement("SELECT SEAT,REG_NO,ROOM_NO FROM ROOM ORDER BY SEAT ASC");
		    rs = pst.executeQuery();
		    table2.setModel(DbUtils.resultSetToTableModel(rs));
		} catch (SQLException e) {
		    // Handle the exception appropriately (e.g., log the error, show an error message)
		    e.printStackTrace();
		}
	}
    public StructClassPage(String AREG_NO) {
    	
    	connect();
    	new FetchStudentsByBranch();
    	new RoomManagement();
    	
		JFrame f = new JFrame("Login");  
		f.getContentPane().setBackground(new Color(0, 0, 70));
	    ImageIcon image = new ImageIcon("arrange-seat1.png");
	    f.setIconImage(image.getImage());
		
	    f.setUndecorated(true);
		f.getContentPane().setLayout(null);
		
		
		// TODO Auto-generated constructor stub
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setBorder(null);
		btnNewButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});
		btnNewButton.setBackground(new Color(242, 242, 242));
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\cancel.png"));
		btnNewButton.setBounds(1315, 10, 40, 25);
		f.getContentPane().add(btnNewButton);
		
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\Logo-medium2.png"));
		lblNewLabel.setBounds(0, 0, 1366, 145);
		f.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 1388, 145);
		f.getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton btnMinimize = new JButton("");
		btnMinimize.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.setState(ICONIFIED);
			}
		});
		btnMinimize.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnMinimize.setBorder(null);
		btnMinimize.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\minimize-sign.png"));
		btnMinimize.setBounds(1270, 10, 40, 25);
		btnMinimize.setBackground(new Color(242, 242, 242));
		panel.add(btnMinimize);
		
		JButton btnHome = new JButton("");
		btnHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
				try {
					new StructAdminMenu(AREG_NO);
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
			}
		});
		btnHome.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnHome.setBorder(null);
		btnHome.setBackground(SystemColor.control);
		btnHome.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\home.png"));
		btnHome.setBounds(10, 10, 40, 40);
		panel.add(btnHome);
		
		JButton btnlogout = new JButton("");
		btnlogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
				new OpeningPage();
			}
		});
		btnlogout.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnlogout.setBorder(null);
		btnlogout.setBackground(SystemColor.control);
		btnlogout.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\logout.png"));
		btnlogout.setBounds(60, 10, 40, 40);
		panel.add(btnlogout);
		
	    JPanel gradientPanel = new JPanel() {
	            @Override
	            protected void paintComponent(Graphics g) {
	                super.paintComponent(g);
	                Graphics2D g2d = (Graphics2D) g.create();
	                int width = getWidth();
	                int height = getHeight();
	                GradientPaint gradient = new GradientPaint(0, 0, new Color(28, 181, 224), 0, height, new Color(0, 0, 70));
	                g2d.setPaint(gradient);
	                g2d.fillRect(0, 0, width, height);
	                g2d.dispose();
	            }
	        };
		gradientPanel.setBounds(0, 0, 1388, 768);
		f.getContentPane().add(gradientPanel);
		gradientPanel.setLayout(null);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "Details", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_1.setBounds(30, 520, 470, 220);
		gradientPanel.add(panel_1);
		panel_1.setLayout(null);
		
		JPanel panel_2 = new JPanel();
		panel_2.setForeground(new Color(255, 255, 255));
		panel_2.setBackground(SystemColor.control);
		panel_2.setOpaque(true);
		panel_2.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_2.setBounds(20, 30, 430, 170);
		panel_1.add(panel_2);
		panel_2.setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("Number of Students");
		lblNewLabel_1.setFont(new Font("Arial", Font.BOLD, 15));
		lblNewLabel_1.setBounds(30, 20, 180, 30);
		panel_2.add(lblNewLabel_1);
		
		tfnumberofstudents = new JTextField();
		tfnumberofstudents.setBackground(new Color(255, 255, 255));
		tfnumberofstudents.setBounds(220, 20, 180, 30);
		panel_2.add(tfnumberofstudents);
		tfnumberofstudents.setColumns(10);
				
		JLabel lblNewLabel_1_1 = new JLabel("Number of Seats");
		lblNewLabel_1_1.setFont(new Font("Arial", Font.BOLD, 15));
		lblNewLabel_1_1.setBounds(30, 70, 180, 30);
		panel_2.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_1_1 = new JLabel("Number of Rooms");
		lblNewLabel_1_1_1.setFont(new Font("Arial", Font.BOLD, 15));
		lblNewLabel_1_1_1.setBounds(30, 120, 180, 30);
		panel_2.add(lblNewLabel_1_1_1);
		
		tfnumberofseats = new JTextField();
		tfnumberofseats.setColumns(10);
		tfnumberofseats.setBackground(Color.WHITE);
		tfnumberofseats.setBounds(220, 71, 180, 30);
		panel_2.add(tfnumberofseats);
		
		tfnumberofrooms = new JTextField();
		tfnumberofrooms.setColumns(10);
		tfnumberofrooms.setBackground(Color.WHITE);
		tfnumberofrooms.setBounds(220, 120, 180, 30);
		panel_2.add(tfnumberofrooms);
		
		updateCounts();
		
		JPanel panel_1_1 = new JPanel();
		panel_1_1.setLayout(null);
		panel_1_1.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "Add Room Details", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_1_1.setBounds(30, 180, 470, 320);
		gradientPanel.add(panel_1_1);
		
		JPanel panel_2_1 = new JPanel();
		panel_2_1.setLayout(null);
		panel_2_1.setOpaque(true);
		panel_2_1.setForeground(Color.WHITE);
		panel_2_1.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel_2_1.setBackground(SystemColor.menu);
		panel_2_1.setBounds(20, 30, 430, 270);
		panel_1_1.add(panel_2_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Room Number");
		lblNewLabel_1_2.setFont(new Font("Arial", Font.BOLD, 20));
		lblNewLabel_1_2.setBounds(30, 30, 180, 30);
		panel_2_1.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_1_2 = new JLabel("Number of Column");
		lblNewLabel_1_1_2.setFont(new Font("Arial", Font.BOLD, 20));
		lblNewLabel_1_1_2.setBounds(30, 90, 180, 30);
		panel_2_1.add(lblNewLabel_1_1_2);
		
		JPanel panel_1_1_1 = new JPanel();
		panel_1_1_1.setLayout(null);
		panel_1_1_1.setBorder(new TitledBorder(new LineBorder(new Color(0, 0, 0)), "Seats", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_1_1_1.setBounds(520, 180, 810, 560);
		gradientPanel.add(panel_1_1_1);
		
		cbcol = new JComboBox();
		cbcol.setModel(new DefaultComboBoxModel(new String[] {"2", "3", "4", "5", "6"}));
		cbcol.setBackground(Color.WHITE);
		cbcol.setBounds(220, 90, 180, 30);
		panel_2_1.add(cbcol);
		
		RoomNo = new JTextField();
		RoomNo.setColumns(10);
		RoomNo.setBackground(Color.WHITE);
		RoomNo.setBounds(220, 30, 180, 30);
		panel_2_1.add(RoomNo);
		
		cbrow = new JComboBox();
		cbrow.setModel(new DefaultComboBoxModel(new String[] {"2", "3", "4", "5", "6", "7", "8", "9", "10"}));
		cbrow.setBackground(Color.WHITE);
		cbrow.setBounds(220, 150, 180, 30);
		panel_2_1.add(cbrow);

		JPanel tablepanel = new JPanel();
		tablepanel.setLayout(null);
		tablepanel.setOpaque(true);
		tablepanel.setForeground(Color.WHITE);
		tablepanel.setBorder(new LineBorder(new Color(0, 0, 0)));
		tablepanel.setBackground(SystemColor.menu);
		tablepanel.setBounds(20, 30, 770, 110);
		panel_1_1_1.add(tablepanel);
		
		seatperrooms = new JTextField();
		seatperrooms.setBounds(400, 20, 110, 30);
		tablepanel.add(seatperrooms);
		seatperrooms.setHorizontalAlignment(SwingConstants.CENTER);
		seatperrooms.setColumns(10);
		seatperrooms.setBackground(Color.WHITE);
		
		SelectRoom = new JComboBox();
		SelectRoom.setBounds(400, 60, 110, 30);
		tablepanel.add(SelectRoom);
		SelectRoom.setBackground(Color.WHITE);
		
		SelectRoom.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        // Get the selected room from the combo box
		    	retrieveNumOfSeatsForRoom();
		   
		    }
		});
		populateRoomComboBox();
			
		JLabel lblNewLabel_1_1_1_1 = new JLabel("Number of Rows");
		lblNewLabel_1_1_1_1.setFont(new Font("Arial", Font.BOLD, 20));
		lblNewLabel_1_1_1_1.setBounds(30, 150, 180, 30);
		panel_2_1.add(lblNewLabel_1_1_1_1);

		
		JButton applybtn = new JButton(" Apply");
		applybtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String addValue = RoomNo.getText();
				SelectRoom.addItem(addValue);
				
				insertRoom();
				int col = Integer.parseInt(cbcol.getSelectedItem().toString());
				int row = Integer.parseInt(cbrow.getSelectedItem().toString());
				int spr = col * row;
				String sspr = String.valueOf(spr);
				seatperrooms.setText(sspr);
				updateCounts();
			}
		});
		applybtn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		applybtn.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\tick.png"));
		applybtn.setFont(new Font("Tahoma", Font.BOLD, 14));
		applybtn.setBackground(Color.WHITE);
		applybtn.setBounds(100, 210, 220, 40);
		panel_2_1.add(applybtn);
		
		JButton applybtn2 = new JButton(" Apply");
		applybtn2.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		applybtn2.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\check.png"));
		applybtn2.setFont(new Font("Tahoma", Font.BOLD, 14));
		applybtn2.setBackground(Color.WHITE);
		applybtn2.setBounds(20, 20, 130, 70);
		tablepanel.add(applybtn2);
		
		JLabel lblNewLabel_1_1_2_1_2 = new JLabel("Seats/Room");
		lblNewLabel_1_1_2_1_2.setBounds(300, 20, 100, 30);
		tablepanel.add(lblNewLabel_1_1_2_1_2);
		lblNewLabel_1_1_2_1_2.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1_1_2_1_2.setFont(new Font("Arial", Font.BOLD, 15));
		
		JLabel lblNewLabel_1_1_2_1_2_1 = new JLabel("Select Room");
		lblNewLabel_1_1_2_1_2_1.setBounds(300, 60, 100, 30);
		tablepanel.add(lblNewLabel_1_1_2_1_2_1);
		lblNewLabel_1_1_2_1_2_1.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel_1_1_2_1_2_1.setFont(new Font("Arial", Font.BOLD, 15));
		
		JButton btnView = new JButton(" View");
		btnView.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new LoadIntoTable();
			}
		});
		btnView.setBounds(520, 20, 110, 70);
		tablepanel.add(btnView);
		btnView.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnView.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\view.png"));
		btnView.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnView.setBackground(Color.WHITE);
		
		JButton btnSave = new JButton(" Save");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new RetrieveDataAndSaveToFile();
			}
		});
		btnSave.setBounds(640, 20, 110, 70);
		tablepanel.add(btnSave);
		btnSave.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnSave.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\diskette.png"));
		btnSave.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnSave.setBackground(Color.WHITE);
		
		JButton deleteRoom = new JButton(" Delete");
		deleteRoom.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				deleteRoom();
				updateCounts();
				populateRoomComboBox();
			}
		});
		deleteRoom.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\bin (1).png"));
		deleteRoom.setFont(new Font("Tahoma", Font.BOLD, 14));
		deleteRoom.setBackground(Color.WHITE);
		deleteRoom.setBounds(160, 20, 130, 70);
		tablepanel.add(deleteRoom);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(20, 160, 330, 380);
		panel_1_1_1.add(scrollPane);
		table = new JTable();
		table.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
			        // This method is invoked when a key is pressed down
				if (e.getKeyCode()==10) {
					addToRooms();
					loadDataIntoTable2();
				}
			}
		});
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int i = table.getSelectedRow();
				TableModel model = table.getModel();
				regNo = model.getValueAt(i, 0).toString();
			}
		});
		scrollPane.setViewportView(table);
		
		JScrollPane scrollPane2 = new JScrollPane();
		scrollPane2.setBounds(460, 160, 330, 380);
		panel_1_1_1.add(scrollPane2);
		
		table2 = new JTable();
		scrollPane2.setViewportView(table2);
		table2.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int i = table2.getSelectedRow();
				TableModel model = table2.getModel();
				SEAT = model.getValueAt(i, 0).toString();
			}
		});
		loadDataIntoTable2();

		
		JButton btnAddToRoom = new JButton("Add");
		btnAddToRoom.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				addToRooms();
				loadDataIntoTable2();
			}
		});
		btnAddToRoom.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnAddToRoom.setBackground(Color.WHITE);
		btnAddToRoom.setBounds(360, 260, 90, 60);
		panel_1_1_1.add(btnAddToRoom);
		
		JButton btnDelete = new JButton("Delete");
		btnDelete.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				delete();
				reset();
				loadDataIntoTable2();
			}
			
		});
		btnDelete.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnDelete.setBackground(Color.WHITE);
		btnDelete.setBounds(360, 340, 90, 60);
		panel_1_1_1.add(btnDelete);
		
		loadDataIntoTable();

		f.setVisible(true);
		f.setSize(1366,768);
	    f.setLocationRelativeTo(null);
    }
    
    public void insertRoom() {
		try {	
			Class.forName("com.mysql.cj.jdbc.Driver"); 
			java.sql.Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange","root","adish");
			
			// Check if REG_NO already exists in the database
			String checkQuery = "SELECT REG_NO FROM STUDENTS WHERE REG_NO = ?";
			PreparedStatement checkPs = con.prepareStatement(checkQuery);
			checkPs.setString(1, RoomNo.getText());
			ResultSet resultSet = checkPs.executeQuery();
			
			if (resultSet.next()) {
				// REG_NO already exists
				JOptionPane.showMessageDialog(f, "Room number already exists!", "Alert", JOptionPane.WARNING_MESSAGE);
			} else {
				// Proceed with inserting the data
				String insertQuery = "INSERT INTO ROOMS (ROOM_NO,NO_OF_COL,NO_OF_ROW) VALUES(?,?,?)";
				PreparedStatement insertPs = con.prepareStatement(insertQuery);
				
				// Set the parameter values for insertion
				insertPs.setString(1, RoomNo.getText());
				insertPs.setString(2, (String) cbcol.getSelectedItem());
				insertPs.setString(3, (String) cbrow.getSelectedItem());
				
				int result = insertPs.executeUpdate();
				if (result == 1) {
					JOptionPane.showMessageDialog(f, "Room Added!", "Success", JOptionPane.PLAIN_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(f, "Something Went Wrong", "Alert", JOptionPane.ERROR_MESSAGE);
					//tfREG_NO.setText("");
					//PAS2.setText("");
				}
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		finally {


		}
    }
}




