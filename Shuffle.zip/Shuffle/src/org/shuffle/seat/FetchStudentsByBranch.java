package org.shuffle.seat;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;



public class FetchStudentsByBranch {
	

    
    public static final List<String> Rooms = null;

	public void storeIntoArray() {
        List<String> Rooms = new ArrayList<>();
        // Database connection details
        String url = "jdbc:mysql://127.0.0.1:3306/seat_arrange";
        String username = "root";
        String password = "adish";
        int totalRecords = 0;

        try (Connection connection = DriverManager.getConnection(url, username, password)) {
            // Fetch REG_NO based on branch condition

            List<String> cseStudents = new ArrayList<>();
            List<String> eceStudents = new ArrayList<>();
            List<String> eeeStudents = new ArrayList<>();
            List<String> meStudents = new ArrayList<>();
            List<String> ceStudents = new ArrayList<>();


            String query = "SELECT REG_NO,BRANCH FROM Students ORDER BY REG_NO ASC";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            
            String countQuery = "SELECT COUNT(*) AS total_records FROM Students";
            Statement countStatement = connection.createStatement();
            ResultSet countResult = countStatement.executeQuery(countQuery);

            if (countResult.next()) {
                totalRecords = countResult.getInt("total_records");
            }         
            //System.out.println("Total Records: " + totalRecords);
            
            while (resultSet.next()) {
                String regNo = resultSet.getString("REG_NO");
                String branch = resultSet.getString("BRANCH");

                if (branch.equals("C S E")) {
                    cseStudents.add(regNo);
                } else if (branch.equals("E C E")) {
                    eceStudents.add(regNo);
                } else if (branch.equals("E E E")) {
                    eeeStudents.add(regNo);
                } else if (branch.equals("M E")) {
                    meStudents.add(regNo);
                } else if (branch.equals("C E")) {
                    ceStudents.add(regNo);
                }
            }
            
            for (int i = 0; i < totalRecords; i++) {
                if (i < cseStudents.size()) {
                	Rooms.add(cseStudents.get(i));
                }
                if (i < eceStudents.size()) {
                	Rooms.add(eceStudents.get(i));
                }
                if (i < eeeStudents.size()) {
                	Rooms.add(eeeStudents.get(i));
                }
                if (i < meStudents.size()) {
                	Rooms.add(meStudents.get(i));
                }
                if (i < ceStudents.size()) {
                	Rooms.add(ceStudents.get(i));
                }
            }
            
//            for (String regNo : Rooms) {
//                System.out.println(regNo);
//            }
//            System.out.println();
        } catch (SQLException e) {
         	e.printStackTrace();
        }
    }
}


