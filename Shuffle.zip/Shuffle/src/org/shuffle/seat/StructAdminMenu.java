package org.shuffle.seat;

import java.awt.Color;
import java.sql.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.JPanel;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.LineBorder;
import javax.swing.UIManager;
import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import com.mysql.cj.jdbc.result.ResultSetMetaData;

import net.proteanit.sql.DbUtils;

import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.border.SoftBevelBorder;
import java.awt.Cursor;
import javax.swing.ListSelectionModel;
import java.awt.SystemColor;
import javax.swing.JComboBox;


public class StructAdminMenu {
	private JFrame f;
	private JTextField SFIELD;
	private JTextField tfROOMS;
	private JTextField tfSEATS;
	private String name;
	private String regNo;
	private String branch;
	private JTextField adstNAME,adstREG_NO,adstDEP;
	private JPanel panel,panel2,panel3,panel4,panel5,panel6,panel7;

		Connection con;
		PreparedStatement pst;
	    PreparedStatement st;
		ResultSet rs,rs1;
		private JTable table;
		private String AREG_NO;
		String REG_NO;

		
		public void roomClass(String REG_NO) {
			// TODO Auto-generated method stub
	        try {   		            
	            pst = con.prepareStatement("SELECT * FROM ROOM WHERE REG_NO = ?");
	            String reg = SFIELD.getText();
	            pst.setString(1,reg);
	            ResultSet rs = pst.executeQuery();
	            if(rs.next()==false) {
	            	JOptionPane.showMessageDialog(f,"User not Found!!","Message", JOptionPane.PLAIN_MESSAGE);
	            	SFIELD.setText("");
	            }
	            else {
	            	String SEAT = rs.getString(1);
	            	String ROOM = rs.getString(3);
	            	
	            	tfROOMS.setText(ROOM);
	            	tfSEATS.setText(SEAT);
	            }
	        } catch(Exception e1) {
	            System.out.println(e1.getMessage());
	        }
			
		}	
		
	public void DeleteConfirm(String AREG_NO) {
		
		this.AREG_NO = AREG_NO;
		try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        String title = "Confirmation";
        String message = "Are you sure you want to delete? This action will log you out from the software, and you will need to create a new account.";
        Object[] options = {"Yes, Delete", "No, Cancel"};
        int opt = JOptionPane.showOptionDialog(null, message, title, JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, null, options, options[1]);
        if (opt == JOptionPane.YES_OPTION) {
			String query = "DELETE FROM ADMIN WHERE REG_NO = ?";
    		try {	
	    		Class.forName("com.mysql.cj.jdbc.Driver"); 
	    		java.sql.Connection con;
	    		con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange","root","adish");			    		
			    PreparedStatement ps = con.prepareStatement(query);  	    		
	    		ps.setString(1,AREG_NO); // Assuming REG_NO is the column name for comparison
	    		int result = ps.executeUpdate();
	    		if (result == 0) {
	    			JOptionPane.showMessageDialog(f,"Something Went Wrong ","Alert",JOptionPane.ERROR_MESSAGE);
	    		}
	    		else{
	    			JOptionPane.showMessageDialog(f,"Account Deleted !!","Bye Bye", JOptionPane.PLAIN_MESSAGE);
	    			f.dispose();
					new StructAdminLogin();
	    		}
    		}catch(Exception e1) {
	    		System.out.println(e1.getMessage());
	    	}
        } else if (opt == JOptionPane.NO_OPTION) {
        	//do nothing
        }
	}	
	
	public void DeleteStudentConfirm(String REG) {
		try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        String title = "Confirmation";
        String message = "Are you sure you want to delete?";
        Object[] options = {"Yes, Delete", "No, Cancel"};
        int opt = JOptionPane.showOptionDialog(null, message, title, JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, null, options, options[1]);
        if (opt == JOptionPane.YES_OPTION) {
			String query = "DELETE FROM STUDENTS WHERE REG_NO = ?";
    		try {				    		
			    PreparedStatement ps = con.prepareStatement(query);  	    		
	    		ps.setString(1,REG); // Assuming REG_NO is the column name for comparison
	    		int result = ps.executeUpdate();
	    		if (result == 0) {
	    			JOptionPane.showMessageDialog(f,"Something Went Wrong ","Alert",JOptionPane.ERROR_MESSAGE);
	    		}
	    		else{
	    			JOptionPane.showMessageDialog(f,"Account Deleted !!","Bye Bye", JOptionPane.PLAIN_MESSAGE);
	    		}
    		}catch(Exception e1) {
	    		System.out.println(e1.getMessage());
	    	}
        } else if (opt == JOptionPane.NO_OPTION) {
        	//do nothing
        }
	}
	
	public void connect() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		    con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange", "root", "adish");
		}catch (ClassNotFoundException | SQLException ex) {
		}
	}
	
	public void loadDataIntoTable() {
		try {
		    pst = con.prepareStatement("SELECT REG_NO, NAME, BRANCH, SEMESTER, YEAR FROM STUDENTS ORDER BY REG_NO ASC");
		    rs = pst.executeQuery();
		    table.setModel(DbUtils.resultSetToTableModel(rs));
		} catch (SQLException e) {
		    // Handle the exception appropriately (e.g., log the error, show an error message)
		    e.printStackTrace();
		}
	}
	
	public void logOutConfirmMessage() {
		try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e1) {
            e1.printStackTrace();
        }
    	String title = "Confirmation";
        String message = "Are you sure you want to SignOut? This action will log you out from the software, and you will need to login Again.";
        Object[] options = {"Yes, LogOut", "No, Cancel"};
        int opt = JOptionPane.showOptionDialog(null, message, title, JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, null, options, options[1]);
        if (opt == JOptionPane.YES_OPTION) {
        	f.dispose();
			new StructAdminLogin();
        } else if (opt == JOptionPane.NO_OPTION) {
        	//do nothing
        }
	}
	
	public void UpdateConfirm(String AREG_NO) throws ClassNotFoundException, SQLException {
		try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e1) {
            e1.printStackTrace();
        }
    	String title = "Confirmation";
        String message = "Are you sure you want to Update?";
        Object[] options = {"Yes", "Cancel"};
        int opt = JOptionPane.showOptionDialog(null, message, title, JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, null, options, options[1]);
        if (opt == JOptionPane.YES_OPTION) {
        	f.dispose();
			new StructAdminUpdate(AREG_NO);
        } else if (opt == JOptionPane.NO_OPTION) {
        	new StructAdminMenu(AREG_NO);
        	//do nothing
        }
	}
	
	public void displayadmin(String AREG_NO) throws SQLException {
	    String dquery = "select * from ADMIN where REG_NO='" + AREG_NO + "';";
		try {
			st = con.prepareStatement(dquery);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    ResultSet r = st.executeQuery();
	    if (r.next()) {
	        int reg = r.getInt(1);
	        String name = r.getString(2);
	        
			JLabel adNAME = new JLabel(": "+name);
			adNAME.setHorizontalAlignment(SwingConstants.LEFT);
			adNAME.setForeground(Color.BLACK);
			adNAME.setFont(new Font("Consolas", Font.BOLD, 20));
			adNAME.setBounds(180, 20, 270, 30);
			panel3.add(adNAME);
			
			JLabel adREG_NO = new JLabel(": "+reg);
			adREG_NO.setHorizontalAlignment(SwingConstants.LEFT);
			adREG_NO.setForeground(Color.BLACK);
			adREG_NO.setFont(new Font("Consolas", Font.BOLD, 20));
			adREG_NO.setBounds(180, 70, 270, 30);
			panel3.add(adREG_NO);
		
	    } else {
			JOptionPane.showMessageDialog(f,"Incorrect Reg. no or Password","Alert",JOptionPane.WARNING_MESSAGE);
	    }
	}
	public StructAdminMenu(String AREG_NO) throws ClassNotFoundException, SQLException {
		
		connect();
		
		
		
		f = new JFrame("StructAdminMenu");  
		f.getContentPane().setBackground(new Color(115, 38, 191));
		ImageIcon image = new ImageIcon("arrange-seat1.png");
	    f.setIconImage(image.getImage());
		
	    f.setUndecorated(true);
		f.getContentPane().setLayout(null);
		
		
		// TODO Auto-generated constructor stub
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setOpaque(false);
		btnNewButton.setBorder(null);
		btnNewButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});
		btnNewButton.setBackground(new Color(242, 242, 242));
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\cancel.png"));
		btnNewButton.setBounds(1315, 10, 40, 25);
		f.getContentPane().add(btnNewButton);
		
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\Logo-medium2.png"));
		lblNewLabel.setBounds(0, 0, 1366, 145);
		f.getContentPane().add(lblNewLabel);
		
		JPanel panel = new JPanel();
		panel.setBounds(0, 0, 1388, 145);
		f.getContentPane().add(panel);
		panel.setLayout(null);
		
		JButton btnMinimize = new JButton("");
		btnMinimize.setOpaque(false);
		btnMinimize.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.setState(f.ICONIFIED);
			}
		});
		btnMinimize.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnMinimize.setBorder(null);
		btnMinimize.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\minimize-sign.png"));
		btnMinimize.setBounds(1270, 10, 40, 25);
		btnMinimize.setBackground(new Color(242, 242, 242));
		panel.add(btnMinimize);
		
		
		JButton btnlogout = new JButton("");
		btnlogout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				logOutConfirmMessage();
			}
		});
		btnlogout.setOpaque(false);
		btnlogout.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnlogout.setBorder(null);
		btnlogout.setBackground(SystemColor.control);
		btnlogout.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\logout.png"));
		btnlogout.setBounds(10, 10, 40, 40);
		panel.add(btnlogout);
		
		panel = new JPanel();
		panel.setBounds(0, 0, 1388, 145);
		f.getContentPane().add(panel);
		
		panel2 = new JPanel();
		panel2.setForeground(new Color(115, 38, 191));
		panel2.setBorder(new TitledBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null), "Admin Details", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel2.setBounds(40, 185, 480, 207);
		f.getContentPane().add(panel2);
		panel2.setLayout(null);
		
		panel3 = new JPanel();
		panel3.setBackground(new Color(255, 255, 255));
		panel3.setLayout(null);
		panel3.setForeground(new Color(115, 38, 191));
		panel3.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel3.setBounds(20, 31, 440, 110);
		panel2.add(panel3);
		
		displayadmin(AREG_NO);

		
		JLabel NAME = new JLabel("Name");
		NAME.setBounds(20, 20, 220, 30);
		panel3.add(NAME);
		NAME.setHorizontalAlignment(SwingConstants.LEFT);
		NAME.setFont(new Font("Consolas", Font.BOLD, 20));
		NAME.setForeground(new Color(0, 0, 0));
		
		JLabel REG_NO1 = new JLabel("RegisterNumber");
		REG_NO1.setBounds(20, 70, 220, 30);
		panel3.add(REG_NO1);
		REG_NO1.setHorizontalAlignment(SwingConstants.LEFT);
		REG_NO1.setForeground(Color.BLACK);
		REG_NO1.setFont(new Font("Consolas", Font.BOLD, 20));

	    //UPDATE ADMIN
	    
		JButton Update = new JButton("  Update");
		Update.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		Update.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\refresh.png"));
		Update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					UpdateConfirm(AREG_NO);
				} catch (ClassNotFoundException | SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				f.dispose();
			}
		});
		Update.setFont(new Font("Microsoft Sans Serif", Font.BOLD, 16));
		Update.setForeground(new Color(0, 0, 70));
		Update.setBackground(new Color(255, 255, 255));
		Update.setBounds(170, 150, 140, 40);
		panel2.add(Update);
		
		JButton btnSignout = new JButton(" Sign Out");
		btnSignout.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnSignout.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\logout 2.png"));
		btnSignout.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				logOutConfirmMessage();
			}
		});
		btnSignout.setForeground(new Color(0, 0, 70));
		btnSignout.setFont(new Font("Microsoft PhagsPa", Font.BOLD, 16));
		btnSignout.setBackground(new Color(255, 255, 255));
		btnSignout.setBounds(20, 150, 140, 40);
		panel2.add(btnSignout);
		
		//DELETE ADMIN
		
		JButton btnDelete = new JButton("  Delete");
		btnDelete.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				DeleteConfirm(AREG_NO);
			}		
		});
		btnDelete.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\bin.png"));
		btnDelete.setForeground(new Color(0, 0, 70));
		btnDelete.setFont(new Font("Microsoft Sans Serif", Font.BOLD, 16));
		btnDelete.setBackground(new Color(255, 255, 255));
		btnDelete.setBounds(320, 150, 140, 40);
		panel2.add(btnDelete);
		
		panel4 = new JPanel();
		panel4.setLayout(null);
		panel4.setForeground(new Color(115, 38, 191));
		panel4.setBorder(new TitledBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null), "Class Details", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel4.setBounds(556, 185, 776, 544);
		f.getContentPane().add(panel4);
		
		panel5 = new JPanel();
		panel5.setBackground(new Color(255, 255, 255));
		panel5.setBounds(20, 30, 735, 70);
		panel4.add(panel5);
		panel5.setLayout(null);
		panel5.setForeground(new Color(115, 38, 191));
		panel5.setBorder(new LineBorder(new Color(0, 0, 0)));
		
		JLabel NAME_1 = new JLabel("Room No");
		NAME_1.setHorizontalAlignment(SwingConstants.LEFT);
		NAME_1.setForeground(Color.BLACK);
		NAME_1.setFont(new Font("Consolas", Font.BOLD, 20));
		NAME_1.setBounds(30, 22, 80, 30);
		panel5.add(NAME_1);
		
		JLabel REG_NO_1 = new JLabel("Seat No");
		REG_NO_1.setHorizontalAlignment(SwingConstants.LEFT);
		REG_NO_1.setForeground(Color.BLACK);
		REG_NO_1.setFont(new Font("Consolas", Font.BOLD, 20));
		REG_NO_1.setBounds(290, 22, 80, 30);
		panel5.add(REG_NO_1);
		
		tfROOMS = new JTextField();
		tfROOMS.setBounds(120, 15, 140, 40);
		panel5.add(tfROOMS);
		tfROOMS.setColumns(10);
		
		tfSEATS = new JTextField();
		tfSEATS.setColumns(10);
		tfSEATS.setBounds(390, 15, 150, 40);
		panel5.add(tfSEATS);
		
		
		JButton btnUpdatetable = new JButton("  Advanced");
		btnUpdatetable.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\advanced-options.png"));
		btnUpdatetable.setBounds(560, 14, 150, 40);
		panel5.add(btnUpdatetable);
		btnUpdatetable.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
				new StructClassPage(AREG_NO);
			}
		});
		btnUpdatetable.setForeground(new Color(0, 0, 70));
		btnUpdatetable.setFont(new Font("Microsoft Sans Serif", Font.BOLD, 16));
		btnUpdatetable.setBackground(new Color(255, 255, 255));
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBackground(new Color(255, 255, 255));
		scrollPane.setBounds(20, 120, 735, 400);
		panel4.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setBorder(new LineBorder(new Color(0, 0, 0)));
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				"REG_NO", "NAME", "BRANCH", "SEMESTER", "YEAR"
			}
		));
		table.getColumnModel().getColumn(0).setPreferredWidth(130);
		table.getColumnModel().getColumn(1).setPreferredWidth(270);
		table.getColumnModel().getColumn(2).setPreferredWidth(90);
		loadDataIntoTable();

		
		panel6 = new JPanel();
		panel6.setLayout(null);
		panel6.setForeground(new Color(115, 38, 191));
		panel6.setBorder(new TitledBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null), "Student Details", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel6.setBounds(40, 429, 480, 300);
		f.getContentPane().add(panel6);
		
		panel7 = new JPanel();
		panel7.setBackground(new Color(255, 255, 255));
		panel7.setLayout(null);
		panel7.setForeground(new Color(115, 38, 191));
		panel7.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel7.setBounds(20, 30, 440, 155);
		panel6.add(panel7);
		
		JLabel NAME_2 = new JLabel("Name");
		NAME_2.setHorizontalAlignment(SwingConstants.LEFT);
		NAME_2.setForeground(Color.BLACK);
		NAME_2.setFont(new Font("Consolas", Font.BOLD, 20));
		NAME_2.setBounds(20, 20, 220, 30);
		panel7.add(NAME_2);
		
		JLabel stREG_NO = new JLabel("RegisterNumber");
		stREG_NO.setHorizontalAlignment(SwingConstants.LEFT);
		stREG_NO.setForeground(Color.BLACK);
		stREG_NO.setFont(new Font("Consolas", Font.BOLD, 20));
		stREG_NO.setBounds(20, 65, 220, 30);
		panel7.add(stREG_NO);
		
		
		//ADD STUDENT BUTTON
		
		JButton btnAdd = new JButton("  Add");
		btnAdd.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnAdd.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e)  {
				new StructAdminAddStudent(AREG_NO);
			}});
		
		btnAdd.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\add-user.png"));
		btnAdd.setForeground(new Color(0, 0, 70));
		btnAdd.setFont(new Font("Microsoft Sans Serif", Font.BOLD, 16));
		btnAdd.setBackground(new Color(255, 255, 255));
		btnAdd.setBounds(20, 240, 140, 40);
		panel6.add(btnAdd);
		
		SFIELD = new JTextField();
		SFIELD.setBounds(20, 195, 320, 35);
		panel6.add(SFIELD);
		SFIELD.setColumns(10);
		
		//SEARCH BTN
		
		JButton SEARCHBTN = new JButton("");
		SEARCHBTN.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		SEARCHBTN.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		    	connect();
		        try {   	
		    		roomClass(REG_NO);

		            pst = con.prepareStatement("SELECT * FROM STUDENTS WHERE NAME LIKE ? OR REG_NO = ?");
		            String reg = SFIELD.getText();
		            String lname = SFIELD.getText();
		            pst.setString(1,reg);
		            pst.setString(2,lname);
		            ResultSet rs = pst.executeQuery();
		            if(rs.next()==false) {
		            	JOptionPane.showMessageDialog(f,"User not Found!!","Message", JOptionPane.PLAIN_MESSAGE);
		            	SFIELD.setText("");
		            }
		            else {
		            	
		            	
		            	String RNUM = rs.getString(1);
		            	String NAM = rs.getString(2);
		            	String DEP = rs.getString(3);
		            	
		            	adstREG_NO.setText(RNUM);
		            	adstNAME.setText(NAM);
		            	adstDEP.setText(DEP);

		            	
		            	JOptionPane.showMessageDialog(f,"User Found!!","Message", JOptionPane.PLAIN_MESSAGE);
		            	System.out.print(regNo);
		            	System.out.print(name);
		            	System.out.print(branch);
		            }
		        } catch(Exception e1) {
		            System.out.println(e1.getMessage());
		        }
		    }
		});

		
		
		
		SEARCHBTN.setBackground(new Color(255, 255, 255));
		SEARCHBTN.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\magnifying-glass.png"));
		SEARCHBTN.setSelectedIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\search.png"));
		SEARCHBTN.setBounds(350, 195, 110, 35);
		panel6.add(SEARCHBTN);
		
		//DELETE STUDENT
		
		JButton btnstdDelete = new JButton("  Delete");
		btnstdDelete.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnstdDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String REG = adstREG_NO.getText();
				connect();
				DeleteStudentConfirm(REG);
			}
		});
		btnstdDelete.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\bin.png"));
		btnstdDelete.setForeground(new Color(0, 0, 70));
		btnstdDelete.setFont(new Font("Microsoft Sans Serif", Font.BOLD, 16));
		btnstdDelete.setBackground(new Color(255, 255, 255));
		btnstdDelete.setBounds(170, 240, 140, 40);
		panel6.add(btnstdDelete);
		
		//UPDATE STUDENT
		
		JButton btnUpdate = new JButton("  Update");
		btnUpdate.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnUpdate.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String REG_NO = adstREG_NO.getText();
				new StructUserUpdate(REG_NO);
			}
			
		});
		btnUpdate.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\refresh.png"));
		btnUpdate.setForeground(new Color(0, 0, 70));
		btnUpdate.setFont(new Font("Microsoft Sans Serif", Font.BOLD, 16));
		btnUpdate.setBackground(new Color(255, 255, 255));
		btnUpdate.setBounds(320, 240, 140, 40);
		panel6.add(btnUpdate);
		
		JLabel REG_NO1_1_1 = new JLabel("Department");
		REG_NO1_1_1.setHorizontalAlignment(SwingConstants.LEFT);
		REG_NO1_1_1.setForeground(Color.BLACK);
		REG_NO1_1_1.setFont(new Font("Consolas", Font.BOLD, 20));
		REG_NO1_1_1.setBounds(20, 111, 220, 30);
		panel7.add(REG_NO1_1_1);
		
		adstNAME = new JTextField();
		adstNAME.setHorizontalAlignment(SwingConstants.LEFT);
		adstNAME.setForeground(Color.BLACK);
		adstNAME.setFont(new Font("Consolas", Font.BOLD, 20));
		adstNAME.setBounds(180, 10, 250, 35);
		panel7.add(adstNAME);
		
		adstREG_NO = new JTextField();
		adstREG_NO.setHorizontalAlignment(SwingConstants.LEFT);
		adstREG_NO.setForeground(Color.BLACK);
		adstREG_NO.setFont(new Font("Consolas", Font.BOLD, 20));
		adstREG_NO.setBounds(180, 60, 250, 35);
		panel7.add(adstREG_NO);
        
		adstDEP = new JTextField();
		adstDEP.setHorizontalAlignment(SwingConstants.LEFT);
		adstDEP.setForeground(Color.BLACK);
		adstDEP.setFont(new Font("Consolas", Font.BOLD, 20));
		adstDEP.setBounds(180, 110, 250, 35);
		panel7.add(adstDEP);
		panel.setLayout(null);
		
	    JPanel gradientPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                int width = getWidth();
                int height = getHeight();
                GradientPaint gradient = new GradientPaint(0, 0, new Color(28, 181, 224), 0, height, new Color(0, 0, 70));
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, width, height);
                g2d.dispose();
            }
        };
	gradientPanel.setBounds(0, 0, 1388, 768);
	f.getContentPane().add(gradientPanel);
	gradientPanel.setLayout(null);
		
		f.setVisible(true);
		f.setSize(1366,768);
	    f.setLocationRelativeTo(null);   
	}
}

