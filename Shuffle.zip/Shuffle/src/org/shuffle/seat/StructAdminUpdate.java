package org.shuffle.seat;

import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Cursor;

public class StructAdminUpdate {
	private JTextField tfName;
	private JPasswordField PAS1;
	private String AREG_NO;
	

	public StructAdminUpdate(String AREG_NO) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated constructor stub
		this.AREG_NO = AREG_NO;

		
		StructAdminMenu adm = new StructAdminMenu(AREG_NO);

		
		
		JFrame f = new JFrame("Login");  
		JLabel title,labReg;
		
	    ImageIcon image = new ImageIcon("arrange-seat1.png");
	    f.setIconImage(image.getImage());
	    title=new JLabel("Admin Update");
	    title.setForeground(new Color(42, 13, 66));
	    title.setHorizontalAlignment(SwingConstants.CENTER);
	    title.setFont(new Font("Arial", Font.BOLD, 25));
	    title.setBounds(80,150, 369,58);
	    f.setUndecorated(true);
	    
	    JTextField tfREG_NO; JPasswordField PAS2;
	    tfREG_NO = new JTextField();
	    tfREG_NO.setBounds(152,240,240,40);
	    
		tfREG_NO.setText(AREG_NO);
		tfREG_NO.setEditable(false);
	    
		tfName = new JTextField();
		tfName.setBounds(152, 320, 240, 40);
		f.getContentPane().add(tfName);
		
		PAS1 = new JPasswordField();
		PAS1.setBounds(152, 400, 240, 40);
		f.getContentPane().add(PAS1);
	    
	    PAS2 = new JPasswordField();
	    PAS2.setBounds(152,480,240,40);
	    f.getContentPane().add(PAS2);
	    
	    JLabel lblNewLabel = new JLabel("");
	    lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
	    lblNewLabel.setBounds(550, 164, 806, 390);
	    f.getContentPane().add(lblNewLabel);
	    lblNewLabel.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\Logo-Large.png"));
	    
	    JButton log;
	    log = new JButton(" Update");
	    log.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\refresh (1).png"));
	    log.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	    log.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent evt) {
	    		
	    		if (!(new String(PAS1.getPassword()).equals(new String(PAS2.getPassword()))))
	    		{
	    			JOptionPane.showMessageDialog(f,"You Password Does not Match!","Alert",JOptionPane.WARNING_MESSAGE);
	    		}else {
	    			String query = "UPDATE ADMIN SET REG_NO = ?, NAME = ?, PASSWORD = ? WHERE REG_NO = ?";
	        		try {	
			    		Class.forName("com.mysql.cj.jdbc.Driver"); 
			    		java.sql.Connection con;
			    		con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange","root","adish");			    		

	    			    PreparedStatement ps = con.prepareStatement(query);  	    		
			    		ps.setString(1,tfREG_NO.getText());
			    		ps.setString(2,tfName.getText());
			    		ps.setString(3,PAS1.getText());
			    		ps.setString(4,AREG_NO); // Assuming REG_NO is the column name for comparison
			    		
			    		int result = ps.executeUpdate();
			    		if (result == 1) {
			    			JOptionPane.showMessageDialog(f,"Account Updated !!","Welcome", JOptionPane.PLAIN_MESSAGE);
			    			f.dispose();
			    			new StructAdminMenu(tfREG_NO.getText());
			    			
			    		}
			    		else {
			    		
			    			JOptionPane.showMessageDialog(f,"Something Went Wrong ","Alert",JOptionPane.ERROR_MESSAGE);
			    			tfREG_NO.setText("");
			    			PAS2.setText("");
			    		}
			    		
			    	}catch(Exception e) {
			    		System.out.println(e.getMessage());
			    	}
	    		}
	    	}
	    });
	    log.setFont(new Font("Tahoma", Font.BOLD, 17));

	    log.setBounds(152,560,240,40);
	    log.setBackground(new Color(42, 13, 66));
	    log.setForeground(new Color(255, 255, 255));
	    log.setBorderPainted(false);
	    
	    JLabel lblPassword_1 = new JLabel("Confirm Password");
	    lblPassword_1.setForeground(new Color(42, 13, 66));
	    lblPassword_1.setHorizontalAlignment(SwingConstants.LEFT);
	    lblPassword_1.setFont(new Font("Arial", Font.PLAIN, 15));
	    lblPassword_1.setBounds(160, 450, 146, 40);
	    f.getContentPane().add(lblPassword_1);
	    labReg = new JLabel("Register No");
	    labReg.setForeground(new Color(42, 13, 66));
	    labReg.setFont(new Font("Arial", Font.PLAIN, 15));
	    labReg.setHorizontalAlignment(SwingConstants.LEFT);
	    labReg.setBounds(160,210, 146,40);
	    f.getContentPane().add(labReg);

	    f.getContentPane().add(title);f.getContentPane().add(tfREG_NO);
	    f.getContentPane().add(log);
	    f.setSize(1366,768);  
	    f.getContentPane().setLayout(null);  
	    f.setVisible(true);  
		f.setResizable(false);
		f.getContentPane().setBackground(new Color(170, 111, 219));
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(539, -11, 850, 789);
		f.getContentPane().add(panel);
		
		JLabel lblName = new JLabel("Name");
		lblName.setHorizontalAlignment(SwingConstants.LEFT);
		lblName.setForeground(new Color(42, 13, 66));
		lblName.setFont(new Font("Arial", Font.PLAIN, 15));
		lblName.setBounds(160, 290, 146, 40);
		f.getContentPane().add(lblName);
		
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setHorizontalAlignment(SwingConstants.LEFT);
		lblPassword.setForeground(new Color(42, 13, 66));
		lblPassword.setFont(new Font("Arial", Font.PLAIN, 15));
		lblPassword.setBounds(160, 370, 146, 40);
		f.getContentPane().add(lblPassword);
		
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(100, 120, 340, 530);
		f.getContentPane().add(panel_1);
		
		JButton btnMinimize = new JButton("");
		btnMinimize.setOpaque(false);
		btnMinimize.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.setState(f.ICONIFIED);
			}
		});
		panel.setLayout(null);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});
		btnNewButton.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\cancel.png"));
		btnNewButton.setOpaque(false);
		btnNewButton.setBorder(null);
		btnNewButton.setBackground(new Color(242, 242, 242));
		btnNewButton.setBounds(780, 20, 40, 25);
		panel.add(btnNewButton);
		btnMinimize.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnMinimize.setBorder(null);
		btnMinimize.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\minimize-sign.png"));
		btnMinimize.setBounds(730, 20, 40, 25);
		btnMinimize.setBackground(new Color(242, 242, 242));
		panel.add(btnMinimize);
		
	    JPanel gradientPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                int width = getWidth();
                int height = getHeight();
                GradientPaint gradient = new GradientPaint(0, 0, new Color(28, 181, 224), 0, height, new Color(0, 0, 70));
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, width, height);
                g2d.dispose();
            }
        };
        gradientPanel.setBounds(0, 0, 1366, 768);
        f.getContentPane().add(gradientPanel);
        gradientPanel.setLayout(null);
        
        
        JButton btnlogout = new JButton("");
        btnlogout.setBounds(10, 10, 40, 40);
        gradientPanel.add(btnlogout);
        btnlogout.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		adm.logOutConfirmMessage();
        	}
        });
        btnlogout.setOpaque(false);
        btnlogout.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        btnlogout.setBorder(null);
        btnlogout.setBackground(SystemColor.control);
        btnlogout.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\logout.png"));
	    f.setLocationRelativeTo(null);
	}
}
