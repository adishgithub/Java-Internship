package org.shuffle.seat;

import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.SystemColor;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.Cursor;

public class StructAdminLogin {

	public StructAdminLogin() {
		JFrame f = new JFrame("Login");  
		JLabel title,labReg;
		
		ImageIcon image = new ImageIcon("arrange-seat1.png");
	    f.setIconImage(image.getImage());
	    title=new JLabel("Admin Login");
	    title.setForeground(new Color(42, 13, 66));
	    title.setHorizontalAlignment(SwingConstants.CENTER);
	    title.setFont(new Font("Arial", Font.BOLD, 25));
	    title.setBounds(80,210, 369,58);
	    f.setUndecorated(true);
	    
	    JTextField ID; JPasswordField PAS;
	    ID = new JTextField();
	    ID.setBounds(152,300,240,40);
	    
	    JLabel lblNewLabel = new JLabel("");
	    lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
	    lblNewLabel.setBounds(550, 164, 800, 390);
	    f.getContentPane().add(lblNewLabel);
	    lblNewLabel.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\Logo-Large.png"));
	    
	    PAS = new JPasswordField();
	    PAS.setBounds(152,380,240,40);
	    f.getContentPane().add(PAS);
	    
	    JButton log;
	    log = new JButton(" Login");
	    log.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\user (1).png"));
	    log.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
	    log.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent evt) {
	    		try {	

		    		
		    		Class.forName("com.mysql.cj.jdbc.Driver"); 
		    		java.sql.Connection conn;
		    		conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/seat_arrange","root","adish");

		    		String AREG_NO = ID.getText();
		    		String pas = PAS.getText();
		    		String query = "select * from ADMIN where REG_NO ='"+ID.getText()+"' and PASSWORD='"+pas+"'";

		    		PreparedStatement stmt=conn.prepareStatement(query);  	    		
		    		ResultSet rs = stmt.executeQuery(query);
		    		
		    		if (rs.next()) {
		    			new StructAdminMenu(AREG_NO);
		    			f.dispose();
		    		}
		    		else {
		    		
		    			JOptionPane.showMessageDialog(f,"Incorrect Reg. no or Password","Alert",JOptionPane.WARNING_MESSAGE);
		    			ID.setText("");
		    			PAS.setText("");
		    		}
		    		
		    	}catch(Exception e) {
		    		System.out.println(e.getMessage());
		    	}
	    	}
	    });
	    log.setFont(new Font("Tahoma", Font.BOLD, 17));

	    log.setBounds(152,450,240,40);
	    log.setBackground(new Color(0, 0, 70));
	    log.setForeground(new Color(255, 255, 255));
	    log.setBorderPainted(false);
	    
	    JLabel lblPassword_1 = new JLabel("Password");
	    lblPassword_1.setForeground(new Color(42, 13, 66));
	    lblPassword_1.setHorizontalAlignment(SwingConstants.LEFT);
	    lblPassword_1.setFont(new Font("Arial", Font.PLAIN, 15));
	    lblPassword_1.setBounds(160, 351, 146, 40);
	    f.getContentPane().add(lblPassword_1);
	    labReg = new JLabel("Register No");
	    labReg.setForeground(new Color(42, 13, 66));
	    labReg.setFont(new Font("Arial", Font.PLAIN, 15));
	    labReg.setHorizontalAlignment(SwingConstants.LEFT);
	    labReg.setBounds(160,269, 146,40);
	    f.getContentPane().add(labReg);

	    
		JButton btnClose = new JButton("");
		btnClose.setOpaque(false);
		btnClose.setBorder(null);
		btnClose.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		btnClose.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				f.dispose();
			}
		});
		btnClose.setBackground(new Color(28, 181, 224));
		btnClose.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\cancel.png"));
		btnClose.setBounds(1315, 10, 40, 25);
		f.getContentPane().add(btnClose);

	    f.getContentPane().add(title);f.getContentPane().add(ID);
	    f.getContentPane().add(log);
	    f.setSize(1366,768);  
	    f.getContentPane().setLayout(null);  
	    f.setVisible(true);  
		f.setResizable(false);
		f.getContentPane().setBackground(new Color(170, 111, 219));
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(530, 0, 838, 768);
		f.getContentPane().add(panel);
		
		JLabel lblNewLabel_1 = new JLabel("Don't have an account?, Click here ");
		lblNewLabel_1.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		lblNewLabel_1.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				new StructAdminSignUp();
				f.dispose();
			}
		});
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setBounds(100, 545, 340, 30);
		f.getContentPane().add(lblNewLabel_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(255, 255, 255));
		panel_1.setBounds(100, 170, 340, 380);
		f.getContentPane().add(panel_1);
		
		JButton backbutton = new JButton("");
		backbutton.setOpaque(false);
		backbutton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		backbutton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				new OpeningPage();
				f.dispose();
			}
		});
		backbutton.setForeground(new Color(170, 111, 219));
		backbutton.setBackground(new Color(170, 111, 219));
		backbutton.setIcon(new ImageIcon("C:\\Users\\adish\\Desktop\\WorkSpace\\Java Training\\Shuffle\\src\\org\\shuffle\\icon\\left.png"));
		backbutton.setBounds(10, 10, 40, 40);
		backbutton.setBorder(null);
		f.getContentPane().add(backbutton);
		
	    JPanel gradientPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2d = (Graphics2D) g.create();
                int width = getWidth();
                int height = getHeight();
                GradientPaint gradient = new GradientPaint(0, 0, new Color(28, 181, 224), 0, height, new Color(0, 0, 70));
                g2d.setPaint(gradient);
                g2d.fillRect(0, 0, width, height);
                g2d.dispose();
                

            }
        };
		gradientPanel.setBounds(0, 0, 1366, 768);
	    f.getContentPane().add(gradientPanel);
	    gradientPanel.setLayout(null);
	    f.setLocationRelativeTo(null);
	}
}
